title: 遍历Java对象,并执行其中的方法(通过反射执行方法)
date: '2014-02-19 17:23:47'
updated: '2014-02-19 17:23:47'
tags: [CSDN迁移]
permalink: /articles/2014/02/19/1566182604993.html
---
for(int i = 0; i < ss.getClass().getMethods().length;i++){  
 Method f = ss.getClass().getMethods()[i];  
 if(f.getName().startsWith("get") && f.getParameterTypes().length == 0){  
 System.out.print(f.getName() + " = ");  
 String o = f.invoke(ss, null) == null ? "" : f.invoke(ss, null).toString();  
 System.out.println(o);  
 }  
 }  
**注:ss是对象  
  
 遍历对象所有成员变量,并取其值  
**for(int i = 0; i < ss.getClass().getDeclaredFields().length;i++){  
 System.out.println(ss.getClass().getDeclaredFields()[i].getName());  
 }  
**遍历对象的父类的所有成员变量,并取其值**  
 for(int i = 0; i < ss.getClass().getSuperclass().getDeclaredFields().length;i++){  
 System.out.println(ss.getClass().getSuperclass().getDeclaredFields()[i].getName());  
 }