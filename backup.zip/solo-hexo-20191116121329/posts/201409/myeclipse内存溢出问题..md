title: myeclipse内存溢出问题 .
date: '2014-09-29 01:51:35'
updated: '2014-09-29 01:51:35'
tags: [CSDN迁移]
permalink: /articles/2014/09/29/1566182601024.html
---
1、修改eclipse.ini   
  
 在Myeclipse安装目录下G:\MyEclipse8.5\Genuitec\MyEclipse 8.5有一个myeclipse.ini配置文件，设置如下：   
  
 -vmargs  
 -Xmx512m  
 -XX:MaxPermSize=256m  
 -XX:ReservedCodeCacheSize=64m  
  
 2、设置Default VM Arguments   
  
 在myEclipse中，打开Windows-> Preferences->Java->Installed JREs->点击正在使用的JDK->Edit->Default VM Arguments文本框中输入：-Xms64m -Xmx256m  
  
 3、如果是web工程还报内存溢出，可能就要设置tomcat内存。

 （1）tomcat的安装根目录%tomcat%bin/catalina.bat文件，SET JAVA_OPTS 一行；

 （2）myeclipse配置web服务器配置 Window—Preferences—Myeclipse—Servers—tomcat 5.x—JDK的Optional Java VM arguments配置为：

 -Xms256m -Xmx512m -XX:MaxNewSize=256m -XX:MaxPermSize=256m