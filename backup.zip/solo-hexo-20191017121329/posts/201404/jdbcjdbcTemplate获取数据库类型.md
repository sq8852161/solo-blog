title: jdbc,jdbcTemplate获取数据库类型
date: '2014-04-10 22:33:24'
updated: '2014-04-10 22:33:24'
tags: [CSDN迁移]
permalink: /articles/2014/04/10/1566182604448.html
---
很多时候，系统需要连接多个数据库处理，或者考虑代码兼容不同数据库的问题。当然是用hibernate无需考虑这些问题，但是如果想只用jdbc就必须考虑这个问题了，因为不同数据库是用的sql语法都不相同。   
那如何确定获取数据库类型呢，在网上搜罗了许久，终于有所收获。如下：   
如果使用的spring的jdbcTemplate，可以这样获取：   

```
DatabaseMetaData md = this.jdbcTemplate.getDataSource().getConnection().getMetaData();  
        System.out.println(md.getDatabaseProductName());  
        System.out.println(md.getDatabaseProductVersion());  
```
  
如果是自己配置的dataSource，可以直接拿到Connection，然后获取DatabaseMetaData，如：   

```
try {  
      String url = "jdbc:odbc:yourdatabasename";  
      String driver = "sun.jdbc.odbc.JdbcOdbcDriver";  
      String user = "guest";  
      String password = "guest";  
  
      Class.forName(driver);  
      Connection connection = DriverManager.getConnection(url, user, password);  
      DatabaseMetaData meta = connection.getMetaData();  
  
      System.out.println("We are using " + meta.getDatabaseProductName());  
      System.out.println("Version is " + meta.getDatabaseProductVersion() );  
  
      connection.close();  
    } catch (Exception e) {  
      System.err.println(e);  
    }  
```