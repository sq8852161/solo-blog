title: java 反射常用方法
date: '2014-02-27 23:53:09'
updated: '2014-02-27 23:53:09'
tags: [CSDN迁移]
permalink: /articles/2014/02/27/1566182612694.html
---
在JDK中，主要由以下类来实现Java反射机制，这些类都位于java.lang.reflect包中：  
 1.Class类：代表一个类。  
 2.Field类：代表类的成员变量（成员变量也称为类的属性）。  
 3.Method类：代表类的方法。  
 4.Constructor类：代表类的构造方法。  
 5.Array类：提供了动态创建数组，以及访问数组元素的静态方法。  
 ◆.Class类  
 在java.lang.Object类中定义了getClass()方法，因此对于任意一个Java对象，都可以通过此方法获得对象的类型。  
 Class类是Reflection API中的核心类，它有以下方法  
 （1）获得对象的类型：  
 getName()：获得类的完整名字。  
 getFields()：获得类的public类型的属性。  
 getDeclaredFields()：获得类的所有属性。  
 getMethods()：获得类的public类型的方法。  
 getDeclaredMethods()：获得类的所有方法。  
 getMethod(String name, Class[] parameterTypes)：获得类的特定方法，name参数指定方法的名字，parameterTypes参数指定方法的参数类型。  
 getConstrutors()：获得类的public类型的构造方法。  
 getConstrutor(Class[] parameterTypes)：获得类的特定构造方法，parameterTypes参数指定构造方法的参数类型。  
 newInstance()：通过类的不带参数的构造方法创建这个类的一个对象。  
 （2）通过默认构造方法创建一个新的对象：  
 Object objectCopy=classType.getConstructor(new Class[]{}).newInstance(new Object[]{});  
 （3）获得对象的所有属性：  
 Field fields[]=classType.getDeclaredFields();  
 Class类的getDeclaredFields()方法返回类的所有属性，包括public、protected、默认和private访问级别的属性。  
 以上代码先调用Class类的getConstructor()方法获得一个Constructor对象，它代表默认的构造方法，然后调用Constructor对象的newInstance()方法构造一个实例。  
 （4）获得每个属性相应的getXXX()和setXXX()方法，然后执行这些方法，把原来对象的属性复制到新的对象中：  
 for(int i=0; i Field field=fields[i];   
 String fieldName=field.getName();   
 String firstLetter=fieldName.substring(0,1).toUpperCase();   
 //获得和属性对应的getXXX()方法的名字 String getMethodName="get"+firstLetter+fieldName.substring(1);   
 //获得和属性对应的setXXX()方法的名字 String setMethodName="set"+firstLetter+fieldName.substring(1);   
 //获得和属性对应的getXXX()方法   
 Method getMethod=classType.getMethod(getMethodName,new Class[]{});   
 //获得和属性对应的setXXX()方法   
 Method setMethod=classType.getMethod(setMethodName,new Class[]{field.getType()});   
 //调用原对象的getXXX()方法   
 Object value=getMethod.invoke(object,new Object[]{});   
 System.out.println(fieldName+":"+value);   
 //调用复制对象的setXXX()方法   
 setMethod.invoke(objectCopy,new Object[]{value});}  
 ◆.Method类的invoke(Object obj,Object args[])方法接收的参数必须为对象，如果参数为基本类型数据，必须转换为相应的包装类型的对象。  
 invoke()方法的返回值总是对象，如果实际被调用的方法的返回类型是基本类型数据，那么invoke()方法会把它转换为相应的包装类型的对象，再将其返回。  
 ◆.Array类  
 java.lang.Array类提供了动态创建和访问数组元素的各种静态方法。如例程10-4所示的ArrayTester1类的main()方法创建了一个长度为10的字符串数组，接着把索引位置为5的元素设为“hello”，然后再读取索引位置为5的元素的值。  
 import java.lang.reflect.*;  
 public class ArrayTester1 {  
 public static void main(String args[])throws Exception {   
 Class classType = Class.forName("java.lang.String");   
 //创建一个长度为10的字符串数组   
 Object array = Array.newInstance(classType, 10);   
 //把索引位置为5的元素设为"hello"   
 Array.set(array, 5, "hello");   
 //读取索引位置为5的元素的值   
 String s = (String) Array.get(array, 5); System.out.println(s); }}