title: js怎么实现文本框中的颜色变化
date: '2014-04-01 17:22:47'
updated: '2014-04-01 17:22:47'
tags: [CSDN迁移]
permalink: /articles/2014/04/01/1566182608918.html
---
```
需求：html中input文本框，当获得焦点时，文本框的颜色变化，失去焦点时，恢复原来的颜色。这个用JS怎么弄啊？不用JS也可以，只要能实现在“获得/失去焦点”能改变文本框的颜色，这个都可以。
希望各位大侠能够帮一下小弟啊！



<html>
    <body>
        <form name="testForm">
             
            <input type="input" id="somId" name="UserName" 
            onFocus="document.getElementById('somId').style.backgroundColor='#eee'" 
            οnblur="document.getElementById('somId').style.backgroundColor='#fff'" 
            value="Test">
             
        </form>
    </body>
</html>
```