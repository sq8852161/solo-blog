title: CluderaManager 最全离线安装记录
date: '2019-08-20 14:53:04'
updated: '2019-08-20 15:04:49'
tags: [CluderaManager, 大数据, hadoop]
permalink: /articles/2019/08/20/1566283984393.html
---
### 1,虚拟机安装 Centos7 64位虚拟机 设置root账号密码root
### 2,在vm设置虚拟机桥接模式
### 3,在系统内设置 虚拟机的网卡 
      ip地址设为手动输入

![clipboard1.png](https://img.hacpai.com/file/2019/08/clipboard1-bbcbdeef.png)

![clipboard3.png](https://img.hacpai.com/file/2019/08/clipboard3-3f4b112c.png)

### 4,设置 hostname
 hostnamectl status
     主机

```
     hostnamectl --static set-hostname SP01
     hostname SP02
     hostname SP03
```
   CentOS7要多执行以下这步:
```
        hostnamectl set‐hostname sp01  
```
在相应的节点主机上修改主机名。
```
sudo nano /etc/sysconfig/network
修改或者添加
HOSTNAME= sp01

```

 在每个节点 修改 /etc/hosts文件
```
     sudo nano /etc/hosts 
```
在文件中粘贴以下
```
127.0.0.1 localhost localhost.localdomain localhost4 localhost4.localdomain4 
::1 localhost localhost.localdomain localhost6 localhost6.localdomain6
10.23.0.136 sp01
10.23.0.138 sp02
10.23.0.139 sp03
```

### 5,所有节点关闭防火墙和selinux
```
     systemctl stop firewalld.service
     systemctl disable firewalld.service
     firewall-cmd --state
     sudo nano /etc/selinux/config  
```
进入文件 将 SELINUX=disabled

### 6, 所有节点无密码ssh登录
先在master上执行:
```
     ssh‐keygen ‐t rsa
     ssh‐copy‐id ‐i ~/.ssh/id_rsa.pub root@sp01
```
再在其他节点分别执行以下命令:

```
     ssh-keygen -t rsa
     ssh-copy-id -i ~/.ssh/id_rsa.pub root@sp01
```
在master上,将authorized_keys分发到其他节点服务器:
```
     scp ~/.ssh/authorized_keys root@slave:~/.ssh/
```
 ssh测试
```
      ssh root@sp02
      ssh root@sp01
```
### 7 设置ntp时间同步
所有节点 安装 ntp 
```
     yum -y install ntp
```
主节点设置
```
     mv /etc/ntp.conf /etc/ntp.conf_bak
     sudo nano /etc/ntp.conf
```
写入
```
driftfile /var/lib/ntp/ntp.drift
restrict 10.23.0.0 mask 255.255.254.0 nomodify notrap
server 210.72.145.44 perfer
server 202.112.10.36
server 59.124.196.83
restrict 210.72.145.44 nomodify notrap noquery
restrict 202.112.10.36 nomodify notrap noquery
restrict 59.124.196.83 nomodify notrap noquery
server 127.127.1.0
fudge 127.127.1.0 stratum 10
logfile /var/log/ntp.log
```
设置ntp服务日志
```
nano /etc/sysconfig/ntpd
OPTIONS="-g -l /var/log/ntp.log"
```
子节点设置
```
driftfile /var/lib/ntp/ntp.drift #草稿文件
#日志文件
statsdir /var/log/ntpstats/
statistics loopstats peerstats clockstats
filegen loopstats file loopstats type day enablefilegen peerstats file peerstats type day enable
filegen clockstats file clockstats type day enable
#让NTP Server和其自身保持同步,如果在/etc/ntp.conf中定义的server都不可用时,将使用local时间作为ntp服务提供给ntp客户端
server 10.23.0.136
fudge 10.23.0.136 stratum 5
#不允许来自公网上ipv4和ipv6客户端的访问
restrict -4 default kod notrap nomodify nopeer noquery
restrict -6 default kod notrap nomodify nopeer noquery
# Local users may interrogate the ntp server more closely.
restrict 127.0.0.1
restrict ::1
```
所有节点设置ntp开机启动
```
systemctl enable ntpd.service
systemctl start ntpd.service
systemctl restart ntpd.service
```

节点同步时间
```
ntpdate -u sp01
```

查看同步状态
```
netstat -tlunp | grep ntp
```

重启所有虚拟机
```
reboot
```

注:安装NTP之后,systemctl enable ntpd设置为开机自动启动,但是重启之后NTP并没有启
动,使用```systemctl status ntpd```查看,得到如下信息:
```
● ntpd.service - Network Time Service
Loaded: loaded (/usr/lib/systemd/system/ntpd.service; disabled; vendor preset: disabled)
Active: inactive (dead)
```
从给出的信息可知ntp已被设置为开机启动,但是开机启动并未成功。一般引起这个问题的最为常
见的原因是系统上安装了一个与NTP相冲突的工具:chrony。
如是使用
```
systemctl is-enabled chronyd
```
来查看一下,往往得到的结果是chrony已经被设置为enabled。所以,解决这一问题的方法
就是:
```
systemctl stop chronyd
systemctl disable chronyd
```

### 8, 安装CDH,
将文件拷贝到节点上
先在主节点建立文件
```
mkdir -p /opt/cloudera/parcel-repo/
```

1.首先将 parcels的文件拷贝到主节点
```
scp -r 下载/CDH/CDH5.16.1/parcels/. root@10.23.0.136:/opt/cloudera/parcel-repo
```
重要!
在manifest.json文件中,找到对应版本的秘钥,复制到.sha文件中。如果manifest.json文件中秘钥错误,系统
也会重新下载CDH包。
否则安装查找parcel文件找不到

2.将cloudera-manager.repo文件拷贝到主节点的/etc/yum.repos.d目录中或者安装存储库(所
有节点)
```
scp -r 下载/CDH/CDH5.16.1/cloudera-manager.repo root@10.23.0.136:/etc/yum.repos.d
```
 导入存储库签名GPG密钥:
```
     rpm --import https://archive.cloudera.com/cm5/redhat/7/x86_64/cm/RPM-GPG-KEY-cloudera
```

 验证repo文件是否起效
```
 yum list | grep cloudera
```
 如果列出的不是待安装的版本,执行下面命令重试 (内容为RPMS文件内的RPM包名)
```
 yum clean all
 yum list | grep cloudera
```

3.然后将 jdk 及rpm 文件拷贝到所有节点/root/cdh/cm/目录中
 先在虚拟机中建立文件夹 
```
     mkdir -p /root/cdh/cm/
```
将RPM文件拷贝至虚拟机
```
     scp -r 下载/CDH/CDH5.16.1/RPMS/.  root@10.23.0.136:/root/cdh/cm
     scp -r 下载/CDH/CDH5.16.1/jdk/. root@10.23.0.139:/root/cdh/cm
```

4.cm安装,在所有节点
```
     cd /root/cdh/cm
     yum -y install *.rpm
```

安装完成后 查看已安装文件
```
rpm -qa | grep cloudera
```
然后所有节点添加java环境变量
在 /etc/profile 中的末尾添加
```
sudo nano /etc/profile
JAVA_HOME=/usr/java/jdk1.7.0_67-cloudera
PATH=$JAVA_HOME/bin:$PATH
export JAVA_HOME PATH
```
修改完刷新一下
```
source /etc/profile
```
然后查看java
```
java -version
     java version "1.7.0_67"
     Java(TM) SE Runtime Environment (build 1.7.0_67-b01)
     Java HotSpot(TM) 64-Bit Server VM (build 24.65-b04, mixed mode)
```

安装mysql数据库，详情看Cloudera Manager安装时配置mysql数据库
在https://dev.mysql.com/downloads/file/?id=484537
下载mysql 5.7版

在各个节点上进行MySQL的旧版本卸载：
```
rpm -qa | grep  MySQL
rpm -qa | grep  mariadb
```
用以下命令卸载查出的包
```
rpm -e --nodeps mariadb-libs-5.5.56-2.el7.x86_64
sudo rpm -e mariadb-libs-5.5.56-2.el7.x86_64 --nodeps
```

 
将mysql驱动放到/usr/share/java中，并改名
```
mv mysql-connector-java-5.1.30.jar  mysql-connector-java.jar
```
传输到各个节点
```
scp mysql-connector-java.jar root@rs-slave04:/usr/share/java
```


上传mysql安装包
```
tar -xvf 解压mysql安装包
tar -xvf mysql-5.7.25-1.el7.x86_64.rpm-bundle.tar 
```
```
rpm -ivh mysql*.rpm 安装所有mysql
rpm -ivh mysql-community-common-5.7.25-1.el7.x86_64.rpm
rpm -ivh mysql-community-libs-5.7.25-1.el7.x86_64.rpm
rpm -ivh mysql-community-client-5.7.25-1.el7.x86_64.rpm
rpm -ivh  mysql-community-server-5.7.25-1.el7.x86_64.rpm
rpm -ivh mysql-community-libs-compat-5.7.25-1.el7.x86_64.rpm 
rpm -ivh mysql-community-devel-5.7.25-1.el7.x86_64.rpm  --安装了这个才能升级HUE

service mysqld start
```
找出mysql安装默认生成的密码：
```
cat /var/log/mysqld.log |grep password


2019-02-27T14:58:56.989712Z 1 [Note] A temporary password is generated for root@localhost: oY7i+lGEBd)w
```

查看密码
```
grep 'temporary password' /var/log/mysqld.log 
2016-07-08T02:25:46.311098Z 1 [Note] A temporary password is generated for root@localhost: MtPqF0/oN5zo
其中“MtPqF0/oN5zo”就为我们要找的初始密码
```
修改用户root密码；

登陆mysql：
```
mysql -uroot -p 
oY7i+lGEBd)w
```

修改mysql密码验证复杂度校验 以下语句谁为按长度校验
```
set global validate_password_policy=0;
```
以下语句设置最小可以密码为一位
```
set global validate_password_length=1;
```

在MySQL中修改root密码：
```
set PASSWORD=PASSWORD('123456');
```


开启mysql远程连接
```
grant all on *.* to 'root'@'%' identified by '123456' with grant option;
```

建立各个组件的数据库，及用户名密码
```
CREATE DATABASE hive DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
GRANT ALL ON hive.* TO 'hive'@'%' IDENTIFIED BY 'hive@123';

CREATE DATABASE scm DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
GRANT ALL ON scm.* TO 'scm'@'%' IDENTIFIED BY 'scm@123';
CREATE DATABASE amon DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
GRANT ALL ON amon.* TO 'amon'@'%' IDENTIFIED BY ' amon@123';
CREATE DATABASE rman DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
GRANT ALL ON rman.* TO 'rman'@'%' IDENTIFIED BY 'rman@123';
CREATE DATABASE hue DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
GRANT ALL ON hue.* TO 'hue'@'%' IDENTIFIED BY 'hue@123';
CREATE DATABASE metastore DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
GRANT ALL ON metastore.* TO 'metastore'@'%' IDENTIFIED BY 'metastore@123';
CREATE DATABASE sentry DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
GRANT ALL ON sentry.* TO 'sentry'@'%' IDENTIFIED BY 'sentry@123';
CREATE DATABASE nav DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
GRANT ALL ON nav.* TO 'nav'@'%' IDENTIFIED BY 'nav@123';
CREATE DATABASE navms DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
GRANT ALL ON navms.* TO 'navms'@'%' IDENTIFIED BY 'navms@123';
CREATE DATABASE oozie DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
GRANT ALL ON oozie.* TO 'oozie'@'%' IDENTIFIED BY 'oozie@123';
```

刷新权限：
```
flush privileges;
```

查询修改my.conf
```
find / -name my.cnf
```
备份my.cnf
```
mv my.cnf my.cnf_bak
nano my.cnf
```
添加以下内容：
```
[mysqld]
datadir=/var/lib/mysql
socket=/var/lib/mysql/mysql.sock
transaction_isolation = READ-COMMITTED
# Disabling symbolic-links is recommended to prevent assorted security risks;
# to do so, uncomment this line:
symbolic_links = 0

key_buffer_size = 32M
max_allowed_packet = 32M
thread_stack = 256K
thread_cache_size = 64
query_cache_limit = 8M
query_cache_size = 64M
query_cache_type = 1

max_connections = 550
#expire_logs_days = 10
#max_binlog_size = 100M

#log_bin should be on a disk with enough free space.
#Replace '/var/lib/mysql/mysql_binary_log' with an appropriate path for your
#system and chown the specified folder to the mysql user.
log_bin=/var/lib/mysql/mysql_binary_log

#In later versions of MySQL, if you enable the binary log and do not set
#a server_id, MySQL will not start. The server_id must be unique within
#the replicating group.
server_id=1

binlog_format = mixed

read_buffer_size = 2M
read_rnd_buffer_size = 16M
sort_buffer_size = 8M
join_buffer_size = 8M

# InnoDB settings
innodb_file_per_table = 1
innodb_flush_log_at_trx_commit  = 2
innodb_log_buffer_size = 64M
innodb_buffer_pool_size = 4G
innodb_thread_concurrency = 8
innodb_flush_method = O_DIRECT
innodb_log_file_size = 512M

[mysqld_safe]
log-error=/var/log/mysqld.log
pid-file=/var/run/mysqld/mysqld.pid

sql_mode=STRICT_ALL_TABLES
```

然后重启MySQL服务器
```
service mysqld restart
```


删除此文件：
```
sudo rm /etc/cloudera-scm-server/db.mgmt.properties
sudo rm /etc/cloudera-scm-server/db.properties
```


必须执行此命令，才能使cdh使用MySQL数据库
```
sudo /usr/share/cmf/schema/scm_prepare_database.sh -h 192.168.0.130 mysql scm scm
```
密码scm@123
停止cloudera内置数据库服务
```
service cloudera-scm-server-db stop
```


9.安装CDH
将cloudera‐manager‐installer.bin包拷贝到主节点
```
scp -r 下载/CDH/CDH5.16.1/cloudera-manager-installer.bin root@10.23.0.136:/root/cdh/cm

chmod u+x cloudera-manager-installer.bin
chmod u+x cloudera-manager-installer.bin
```
启动安装
```
./cloudera-manager-installer.bin --skip_repo_package=1
```
如果提示db.properties文件已经存在,则删除
```
rm -rf /etc/cloudera-scm-server/db.properties
```

安装完成了

主节点修改
```
nano /etc/cloudera-scm-agent/config.ini

将其中server_host=rs-master01    rs-master01是主节点名

在主节点将config.ini推送到子节点
scp /etc/cloudera-scm-agent/config.ini root@rs-slave03:/etc/cloudera-scm-agent/
```


现在访问 10.23.0.136:7180端口
账户:admin
密码:admin
选免费版
一路继续
到集群安装 install agaents
如果遇到
安装失败。 无法接收 Agent 发出的检测信号。
请确保主机的名称已正确配置。
请确保端口 7182 可在 Cloudera Manager Server 上访问（检查防火墙规则）。
请确保正在添加的主机上的端口 9000 和 9001 空闲。
检查正在添加的主机上 /var/log/cloudera-scm-agent/ 中的代理日志（某些日志可在安装详细信息中找到）。
如果在 Cloudera Manager 中启用为代理使用 TLS 加密（管理 -> 设置 -> 安全），请确保 /etc/cloudera-scm-agent/config.ini 在正在添加的主机上有 use_tls=1。重启相应的代理，并单击此处的重试链接。

请检查hosts中的配置. 127.0.0.1 不能配置名字


10.警告设置
每个节点都要运行
1.Cloudera 建议将 /proc/sys/vm/swappiness 设置为最大值 10。当前设置为 30。使用 sysctl 命令
在运行时更改该设置并编辑 /etc/sysctl.conf,以在重启后保存该设置。您可以继续进行安装,但 
Cloudera Manager 可能会报告您的主机由于交换而运行状况不良。
sysctl vm.swappiness=10
sudo nano /etc/sysctl.conf
vm.swappiness=10


2.已启用透明大页面压缩,可能会导致重大性能问题。请运行“echo never > 
/sys/kernel/mm/transparent_hugepage/defrag”和“echo never > 
/sys/kernel/mm/transparent_hugepage/enabled”以禁用此设置,然后将同一命令添加到 
/etc/rc.local 等初始化脚本中,以便在系统重启时予以设置。
echo never > /sys/kernel/mm/transparent_hugepage/defrag
echo never > /sys/kernel/mm/transparent_hugepage/enabled

sudo nano /etc/rc.local 

添加以下
if test -f /sys/kernel/mm/transparent_hugepage/enabled; then
echo never > /sys/kernel/mm/transparent_hugepage/enabled
fi
if test -f /sys/kernel/mm/transparent_hugepage/defrag; then
echo never > /sys/kernel/mm/transparent_hugepage/defrag
fi



Hive 
数据库主机名称: 数据库类型: 数据库名称 : 用户名: 密码:
localhost:7432 MySQLPostgreSQLOracle hive hive E3iRjV6KJf
Hue 
数据库主机名称: 数据库类型: 数据库名称 : 用户名: 密码:
localhost:7432 MySQLPostgreSQLOracle hue hue BrR0bfCVce
Oozie Server 
当前被分配在 sp01 上运行。    
数据库主机名称: 数据库类型: 数据库名称 : 用户名: 密码:
localhost:7432 MySQLPostgreSQLOracle oozie_oozie_server oozie_oozie_server wyGtMR0lKy


中间选择加载组件:HBase,HDFS,Hive,Hue,Impala,Spark,Yarn,ZooKeeper

一路继续,直到完成

进入完成页面
HDFS报警,有一个错误.副本块不足.
点击HDFS 在搜索栏搜索
dfs.replication

在主节点 输入su hdfs 进入hdfs角色
hadoop fs -setrep 2 /



如果出现提示:
1
This account is currently not available
解决方法:
1 # vi /etc/passwd
把 hdfs:x:988:982:Hadoop HDFS:/var/lib/hadoop-hdfs:/sbin/nologin
修改为
thdfs:x:988:982:Hadoop HDFS:/var/lib/hadoop-hdfs:/bin/bash 
修改完毕后,保存退出就可以切换了
==CM Portal地址:
  http://master:7180/cmf/home


### 关闭步骤:
1.在CM Portal上关闭cluster
2.在所有节点关闭CM agent:
```
service cloudera-scm-agent stop
```
3.在master节点关闭CM server:
```
service cloudera-scm-server stop
```
### 启动步骤:
1.在所有节点启动CM agent:
```
service cloudera-scm-agent start
```
2.在master节点启动CM server:
```
service cloudera-scm-server start
```
3.在CM portal上启动cluster
查看启动日志:
```
/var/log/cloudera-scm-server/cloudera-scm-server.log
```
查看服务状态
```
systemctl status cloudera-scm-agent
```

监测cloudera启动过程
```
tail -f /var/log/cloudera-scm-server/cloudera-scm-server.log
cat /var/log/cloudera-scm-agent/cloudera-scm-agent.log
```

监控ntp服务
```
watch ntpq -p
```
