title: davinci创建impala，hive jdbc连接
date: '2019-08-20 08:42:05'
updated: '2019-08-20 08:42:05'
tags: [BI, davinci, 数据可视化]
permalink: /articles/2019/08/20/1566261724832.html
---
  

  

环境：cloudera-manager 5.16.1

1，下载hive相关jar包

[https://www.cloudera.com/downloads/connectors/hive/jdbc/2-6-5.html](https://www.cloudera.com/downloads/connectors/hive/jdbc/2-6-5.html)

将相关jar包放入lib

将相关jar包引入项目

![clipboard.png](https://img.hacpai.com/file/2019/08/clipboard-1886ef52.png)




2，在config中的datasource_drive.yml中添加

hive2: name: hive desc: hive driver: com.cloudera.hive.jdbc41.HS2Driver keyword_prefix: keyword_suffix: alias_prefix: \` alias_suffix: \`

  

3，重启davinci

4，在Source中添加

jdbc:hive2://192.168.0.130:10000/default

hdfs

hdfs

  

impala引入过程：

1，在[https://www.cloudera.com/downloads/connectors/impala/jdbc/2-5-28.html](https://www.cloudera.com/downloads/connectors/impala/jdbc/2-5-28.html)

下载相关jar包。

2，jar包存入lib，引入项目

3，重启davinci

4，在soucre中添加

jdbc:impala://192.168.0.178:21050/carddata;auth=noSasl
