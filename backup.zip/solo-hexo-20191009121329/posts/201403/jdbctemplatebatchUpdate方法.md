title: jdbctemplate batchUpdate方法。
date: '2014-03-14 21:21:27'
updated: '2014-03-14 21:21:27'
tags: [CSDN迁移]
permalink: /articles/2014/03/14/1566182605734.html
---
[ ](http://creativecommons.org/licenses/by-sa/4.0/) 版权声明：本文为博主原创文章，遵循[ CC 4.0 by-sa ](http://creativecommons.org/licenses/by-sa/4.0/)版权协议，转载请附上原文出处链接和本声明。  本文链接：[https://blog.csdn.net/u012274449/article/details/21233337](https://blog.csdn.net/u012274449/article/details/21233337)   
    
   在进行新购的时候，需要一次插入大量数据，因此效率较慢，现在采用新的插入方法，jdbctemplate的batchUpdate，大幅度提高了效率。

 在serviceimp层是这样的

 


```
/**
	 * 功能描述：根据传入的数据进行单根插入（修改时新增）
	 * @param newline
	 * @param qtynew
	 * @throws Exception
	 * Company:     dhm 
	 * @author:     dhm  孙鹏  sunpeng2009@foxmail.com
	 * @version:    1.0  
	 * Create at:   2014-2-26 下午01:25:22
	 *
	 * @update:[变更日期YYYY-MM-DD][更改人姓名][变更描述]
	 */
	public void  inserttool(NewLine newline,int qtynew) throws Exception{
		// 对单根钻钻具的属性进行组织
		NewLineTool newlinetool=new NewLineTool();
		newlinetool=intotool(newline);
		final ArrayList<NewLineTool> list=new ArrayList<NewLineTool>();
		final String idlong[] = new String [qtynew];
		String enttype_name=newlinetooldaoimpl.queryForTooid(newlinetool);
		int id=newlinetooldaoimpl.creattoolid(newlinetool,enttype_name);
		for (int i = 0; i < qtynew; i++) {

			id=id+1;
			String name_id=enttype_name+"-"
			+ CommonEx.f_fixstr(6, "0", id);
			String idall=name_id;
			newlinetool.setDrilltool_id(name_id);
			
			list.add(i, newlinetool);
			idlong[i]=idall;
		}
		newlinetooldaoimpl.insert(list,idlong);
	}
```
  
 因为list传递过去之后，所有对象都变为一个，原因是，new对象只new了一个，因此在add之后，引用传递时
```
/**
	 * 功能描述：实现一次插入所有数据
	 * 需要传递包含所有对象的list，以及一个包含对象id的数组，因为在service里声明的时候是声明了一个对象。因此，取出的所有对象都是一个地址的
	 * 值是相同的。
	 * @param list
	 * @param idlong
	 * @return
	 * @throws Exception
	 * Company:     dhm 
	 * @author:     dhm  孙鹏  sunpeng2009@foxmail.com
	 * @version:    1.0  
	 * Create at:   2014-3-14 下午01:19:52
	 *
	 * @update:[变更日期YYYY-MM-DD][更改人姓名][变更描述]
	 */
	@Override
	public int insert(ArrayList<NewLineTool> list,String[] idlong) throws Exception {
//		String sql="insert dtms_doc_newlinetool"+util.getSqlPart(arg0,new String[]{"serialVersionUID"}, 1);	

		final ArrayList<NewLineTool> temList=list;
		final String idnow[]=idlong;
		String sql="INSERT INTO dtms_doc_newlinetool(new_id,newline_id,new_no,drilltool_id," +
				"drilltool_no,drilltool_grade,drilltool_length,drilltooltype_code,manufacture,new_org_code,prod_date,repair_type," +
				"stock_dpt_code,asset_org_code) VALUES(?, ?, ?, ?,?,?,?,?,?,?,?,?,?,?)";
	    try{  
	        int[] ii = this.getJdbcTemplate().batchUpdate(sql, new BatchPreparedStatementSetter(){
	        	 public void setValues(PreparedStatement ps, int i)  
		            throws SQLException {  
		    	NewLineTool arg0 = (NewLineTool)temList.get(i); 
				ps.setString(1, arg0.getNew_id());
				ps.setString(2, arg0.getNewline_id());
				ps.setString(3, arg0.getNew_no());
				ps.setString(4, idnow[i]);
				ps.setString(5, arg0.getDrilltool_no()==null?"":arg0.getDrilltool_no());
				ps.setString(6, arg0.getDrilltool_grade()==null?"":arg0.getDrilltool_grade());
				ps.setString(7, arg0.getDrilltool_length());
				ps.setString(8, arg0.getDrilltooltype_code());
				ps.setString(9, arg0.getManufacture());
				ps.setString(10, arg0.getNew_org_code());
				ps.setString(11, arg0.getProd_date());
				ps.setString(12, arg0.getRepair_type());
				ps.setString(13, arg0.getStock_dpt_code());
				ps.setString(14, arg0.getAsset_org_code());
				
		    }

				@Override
				public int getBatchSize() {
					// TODO Auto-generated method stub
					return temList.size();
				}  
	        });  
	        return ii.length;
	    }catch (org.springframework.dao.DataAccessException e) {  
	        e.printStackTrace();  
	       
	    }
		return 0; 
	   
	}
	
```
  
 ，所有list都指向同一个地址。因此所有取出的数据都是一样的 在这里因为，只有id不同，因此采用了数组传递过去。

 在daoimpl是这样的

 效率提高从1000个数30秒提高到1秒