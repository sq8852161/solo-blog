title: 阿里云下linux系统lyx字库导致jcaptcha图片乱码
date: '2018-10-26 18:53:57'
updated: '2018-10-26 18:53:57'
tags: [CSDN迁移]
permalink: /articles/2018/10/26/1566182609849.html
---
[ ](http://creativecommons.org/licenses/by-sa/4.0/) 版权声明：本文为博主原创文章，遵循[ CC 4.0 by-sa ](http://creativecommons.org/licenses/by-sa/4.0/)版权协议，转载请附上原文出处链接和本声明。  本文链接：[https://blog.csdn.net/u012274449/article/details/83411534](https://blog.csdn.net/u012274449/article/details/83411534)   
    
   今天运行环境报了一个异常.

 找回密码页面![](https://img-blog.csdnimg.cn/20181026104849963.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTIyNzQ0NDk=,size_27,color_FFFFFF,t_70)

 成这个样了..

 系统使用的是JCaptcha插件.

 本地运行,并没有发现异常,检查前后台代码,也无异常.

 因此,怀疑是服务器环境的原因.

 在网上搜索,发现有多类似的情况.[https://blog.csdn.net/zhangming1013/article/details/78326988/](https://blog.csdn.net/zhangming1013/article/details/78326988/)

 

 联系服务器管理员,检查了帖子中所说的 /usr/share/fonts/ 目录,发现了一个名为"lyx"的字库.

 管理员删除了这个字库,然后重启服务.异常解决.