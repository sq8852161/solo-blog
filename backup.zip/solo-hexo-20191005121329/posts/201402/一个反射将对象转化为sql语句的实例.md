title: 一个反射将对象转化为sql语句的实例
date: '2014-02-20 23:22:56'
updated: '2014-02-20 23:22:56'
tags: [CSDN迁移]
permalink: /articles/2014/02/20/1566182614483.html
---
```

//一个反射将对象转化为sql语句的实例。转自weiluo12
public class Student {
    private int studid;
 
    private String major;
 
    private double age;
 
    public Student() {
        super();
    }
 
    public Student(int studid, String major, double age) {
        super();
        this.studid = studid;
        this.major = major;
        this.age = age;
    }
 
    @Override
    public String toString() {
        return "";
    }
 
    public int getStudid() {
        return studid;
    }
 
    public void setStudid(int studid) {
        this.studid = studid;
    }
 
    public String getMajor() {
        return major;
    }
 
    public void setMajor(String major) {
        this.major = major;
    }
 
    public double getAge() {
        return age;
    }
 
    public void setAge(double age) {
        this.age = age;
    }
}
 
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
 
public class ProduceSQL {
 
    /*
     * 通过JAVA的反射机制，给定一个Student的对象例如：
     * 
     * Student stud = new Student(1058, "计算机科学与技术", 22);
     * 
     * 需要根据给定的对象，构造出一条SQL语句：
     * 
     * insert into Student(studid,studname,age) values(1058,'计算机科学与技术',22);
     * 
     */
    public static void main(String[] args) {
        Student stud=new Student(1058,"计算机科学与技术", 22);
        productInsertSQL(stud);
    }
 
    public static String productInsertSQL(Student stud) {
        String result = "";
        StringBuffer sbuf = new StringBuffer();
        sbuf.append("insert into ");
 
        System.out.println("Dubug: ---->>> " + stud.getClass());
        int position = stud.getClass().toString().indexOf("com");
        String fullpackagename = "";
        if (position != -1) {
            fullpackagename = stud.getClass().toString().substring(position);
            System.out.println("Dubug: ---->>> " + fullpackagename);
        }
 
        String tablename = fullpackagename.substring(fullpackagename
                .lastIndexOf(".") + 1);
 
        sbuf.append(tablename + "(");
        Class cs = null;
        try {
            cs = Class.forName(fullpackagename);
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
 
        Field field[] = cs.getDeclaredFields();
        for (int i = 0; i < field.length; i++) {
            String fieldname = field[i].getName();
            sbuf.append(fieldname + ",");
        }
 
        String mid = sbuf.toString();
        int lastpos = mid.lastIndexOf(",");
        if (lastpos != -1) {
            result = mid.substring(0, lastpos) + ")";
        }
 
        result += " values(";
 
        // 取值
        Method[] method = cs.getDeclaredMethods();
        StringBuffer valuesbuf = new StringBuffer();
        for (int i = 0; i < method.length; i++) {
 
            String methodname = method[i].getName();
            try {
                if (methodname.indexOf("get") != -1) {
                    String tmpmethodname = method[i].getName();
 
                    Method methodd = cs.getMethod(tmpmethodname, null);
 
                    // 对反射对象底层的方法进行调用，获得调用该方法所得到的值
                    Object returnobject = methodd.invoke(stud, null);
                    String tmpvalue = "";
                    if (returnobject.getClass().getSimpleName()
                            .equals("String")) {
                        tmpvalue = "'" + returnobject.toString() + "'";
                    } else {
                        tmpvalue = returnobject.toString();
                    }
 
                    valuesbuf.append(tmpvalue + ",");
 
                }
            } catch (SecurityException e) {
                e.printStackTrace();
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
        }
        result += valuesbuf.toString();
 
        int lastpos2 = result.lastIndexOf(",");
        if (lastpos2 != -1) {
            result = result.substring(0, lastpos2) + ")";
        }
        System.out.println(result);
        return result;
    }
 
}
```