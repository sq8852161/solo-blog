title: js打开新窗口的各种方法
date: '2014-02-10 18:12:38'
updated: '2014-02-10 18:12:38'
tags: [CSDN迁移]
permalink: /articles/2014/02/10/1566182607308.html
---
window.location="aaa.aspx"

 上面的方法只能在当前页打开，如果要在新的页面打开，最简单的是用以下方法

 form.target="_blank";  
 form.action="aaa.aspx";  
 form.submit();

 

 

 

 window.top.location=url 可以在iframe中的页面在父窗口刷新打开

 window.open方法可控制的样式丰富，比如我们可以控制窗口显示的大小，窗口显示的内容，以及位置等等。都是使用js中的window.open有一个缺点就是容易被浏览器屏蔽。本文介绍了js中打开新窗口的各种方法。

 **1，打开新窗口全屏**

 <html><head>  
 <title>blue</title>  
 <SCRIPT>  
 function ow(owurl){  
 var tmp=window.open("about:blank","","fullscreen=1")  
 tmp.moveTo(0,0);  
 tmp.resizeTo(screen.width+20,screen.height);  
 tmp.focus();  
 tmp.location=owurl;  
 }  
 </SCRIPT>  
 </head>  
 <body>  
 <ahref="javascript:ow('http://www.aspxhome.com/');">  
 blog</a>

 **2,打开新窗口固定大小**

 <buttonοnclick="window.open('/red/','','width=800,height=300')">open1</button>  
 <button οnclick="varnewwin=window.open('/red/');newwin.moveTo(50,50);newwin.resizeTo(800,300)">open2</button>  
 <buttonοnclick="window.showModelessDialog('/red','','dialogWidth:800px;dialogHeight:300px')">open3</button>

 **3,默认大小开启**

 <script>  
 //tmtC_winMaximizer  
 if (document.layers){  
 var larg=screen.availWidth-10;  
 var altez=screen.availHeight-20;}  
 else{  
 var larg=screen.availWidth-2;  
 var altez=screen.availHeight;}  
 self.resizeTo(larg,altez);  
 self.moveTo(0,0);  
 //tmtC_winMaximizerEnd  
 </script>

 --------------------------------------------

 <scriptlanguage="JavaScript">  
 <!--  
 self.moveTo(0,0)  
 self.resizeTo(screen.availWidth,screen.availHeight)  
 //-->  
 </script>

 **4,正常打开打开一个弹出窗口**

 <scriptlanguage="JavaScript">  
 function WinOpen() {  
 mesg=open("cnrose","DisplayWindow","toolbar=no,,menubar=no,location=no,scrollbars=no");  
 mesg.document.write("<HEAD><TITLE>中国asp之家</TITLE></HEAD>");  
 mesg.document.write("<CENTER>http://www.aspxhome</CENTER>");  
 }  
 </script>  
 <form>  
 <input type="button" name="Button1" value="CN-Bruce"οnclick="WinOpen()">  
 </form>

 ----------------------------------------------------------------------------------------------

 <a href=#οnclick=window.open('http://www.aspxhome','target','param')>a</a>

 **5，Chromeless Window For IE6 SP1**

 <HTML XMLNS:IE>  
 <meta http-equiv="Content-Type" content="text/html;charset=gb2312">  
 <IE:Download ID="include"STYLE="behavior:url(#default#download)" />  
 <title>ChromelessWindow</title>

 <SCRIPTLANGUAGE="JScript">  


 var CW_width = 400;  
 var CW_height = 300;  
 var CW_top = 100;  
 var CW_left = 100;  
 var CW_url = "[http://www.cnbruce.com/bluebook/](http://www.cnbruce.com/bluebook/)";  
 var New_CW = window.createPopup();  
 var CW_Body = New_CW.document.body;  
 var content = "";  
 var CSStext = "margin:1px;color:black; border:2pxoutset;border-style:expression_r(οnmοuseοut=οnmοuseup=function(){this.style.borderStyle='outset'},οnmοusedοwn=function(){if(event.button!=2)this.style.borderStyle='inset'});background-color:buttonface;width:16px;height:14px;font-size:12px;line-height:11px;cursor:Default;";

 //Build Window  
 include.startDownload(CW_url,function(source){content=source});

 function insert_content(){  
 var temp = "";  
 CW_Body.style.overflow = "hidden";  
 CW_Body.style.backgroundColor = "white";  
 CW_Body.style.border = "solid black 1px";  
 content = content.replace(/<a([^>]*)>/g,"<aοnclick='parent.open(this.href);return false'$1>");  
 temp += "<table width=100% height=100% cellpadding=0cellspacing=0 border=0>";  
 temp += "<trstyle=';font-size:12px;background:#0099CC;height:20;cursor:default'οndblclick=\"Max.innerText=Max.innerText=='1'?'2':'1';parent.if_max=!parent.if_max;parent.show_CW();\"οnmοuseup='parent.drag_up(event)'οnmοusemοve='parent.drag_move(event)'οnmοusedοwn='parent.drag_down(event)' onselectstart='return false'οncοntextmenu='return false'>";  
 temp += "<tdstyle='color:#ffffff;padding-left:5px'>ChromelessWindow For IE6 SP1</td>";  
 temp += "<tdstyle='color:#ffffff;padding-right:5px;'align=right>";  
 temp += "<span id=Help οnclick=\"alert('ChromelessWindow For IE6 SP1 - Ver 1.0\\n\\nCode By Windy_sk\\n\\nSpecialThanks For andot')\"style=\""+CSStext+"font-family:System;padding-right:2px;\">?</span>";  
 temp += "<spanid=Min οnclick='parent.New_CW.hide();parent.blur()'style=\""+CSStext+"font-family:Webdings;\"title='Minimum'>0</span>";  
 temp += "<spanid=Max οnclick=\"this.innerText=this.innerText=='1'?'2':'1';parent.if_max=!parent.if_max;parent.show_CW();\"style=\""+CSStext+"font-family:Webdings;\"title='Maximum'>1</span>";  
 temp += "<span id=Closeοnclick='parent.opener=null;parent.close()'style=\""+CSStext+"font-family:System;padding-right:2px;\"title='Close'>x</span>";  
 temp +="</td></tr><tr><tdcolspan=2>";  
 temp += "<div id=includestyle='overflow:scroll;overflow-x:hidden;overflow-y:auto; HEIGHT:100%; width:"+CW_width+"'>";  
 temp += content;  
 temp += "</div>";  
 temp +="</td></tr></table>";  
 CW_Body.innerHTML = temp;  
 }

 setTimeout("insert_content()",1000);

 var if_max = true;  
 function show_CW(){  
 window.moveTo(10000, 10000);  
 if(if_max){  
 New_CW.show(CW_top, CW_left, CW_width, CW_height);  
 if(typeof(New_CW.document.all.include)!="undefined"){  
 New_CW.document.all.include.style.width = CW_width;  
 New_CW.document.all.Max.innerText = "1";  
 }  
  
 }else{  
 New_CW.show(0, 0, screen.width, screen.height);  
 New_CW.document.all.include.style.width = screen.width;  
 }  
 }

 window.onfocus = show_CW;  
 window.onresize = show_CW;

 // Move Window  
 var drag_x,drag_y,draging=false

 function drag_move(e){  
 if (draging){  
 New_CW.show(e.screenX-drag_x, e.screenY-drag_y, CW_width,CW_height);  
 return false;  
 }  
 }

 function drag_down(e){  
 if(e.button==2)return;  
 if(New_CW.document.body.offsetWidth==screen.width&&New_CW.document.body.offsetHeight==screen.height)return;  
 drag_x=e.clientX;  
 drag_y=e.clientY;  
 draging=true;  
 e.srcElement.setCapture();  
 }

 function drag_up(e){  
 draging=false;  
 e.srcElement.releaseCapture();  
 if(New_CW.document.body.offsetWidth==screen.width&&New_CW.document.body.offsetHeight==screen.height) return;  
 CW_top = e.screenX-drag_x;  
 CW_left = e.screenY-drag_y;  
 }

 </SCRIPT>  
 </HTML>

 **6，打开即全屏**

 <html>  
 <head>  
 <meta http-equiv="Content-Type" content="text/html;charset=gb2312">  
 <title>js打开新窗口方法代码收集 - 中国asp之家 -http://www.aspxhome</title>  
 <link href="index.css" rel="stylesheet"type="text/css">  
 <script language="JavaScript"type="text/JavaScript">  
 <!--  
 function MachakFull(Ie,other){  
 x=screen.availWidth;  
 y=screen.availHeight;  
 target =parseFloat(navigator.appVersion.substring(navigator.appVersion.indexOf('.')-1,navigator.appVersion.length));  
 if((navigator.appVersion.indexOf("Mac")!=-1)&&(navigator.userAgent.indexOf("MSIE")!=-1)&&(parseInt(navigator.appVersion)==4))  
 window.open(other,"sub",'scrollbars=yes');  
 if (target >= 4){  
 if (navigator.appName=="Netscape"){  
 varMachakFull=window.open(other,"MachakFull",'scrollbars=yes','width='+x+',height='+y+',top=0,left=0');  
 MachakFull.moveTo(0,0);  
 MachakFull.resizeTo(x,y);}  
 if (navigator.appName=="Microsoft Internet Explorer")  
 window.open(Ie,"MachakFull","fullscreen=yes");  
 }  
 else window.open(other,"sub",'scrollbars=yes');  
 }

 function MM_goToURL() { //v3.0  
 var i, args=MM_goToURL.arguments; document.MM_returnValue =false;  
 for (i=0; i<(args.length-1); i+=2)eval_r(args[i]+".location='"+args[i+1]+"'");  
 }  
 //-->  
 </script>  
 </head>

 <body bgcolor="#3366CC" SCROLL=NOοnlοad="MachakFull('/bbs/','')">

 ----------------------------------------------------------------------------------------------

 <script>  
 window.open('/','','fullscreen=1');  
 window.close();  
 </script>

 **7，网页对话框**

 <script>  
 window.οnlοad=function(){  
 varfeatures='status:0;dialogWidth:470px;dialogHeight:470px;dialogTop:100px;dialogLeft:100px;resizable:0;scroll:0;center:1';  
 showModelessDialog("[http://www.aspxhome/",window,features](http://www.aspxhome/));  
 }  
 function show(laysn)  
 {  
 var obj;  
 obj=laysn.style;  
 obj.visibility='visible';  
 }  
 function hidden(laysn)  
 {  
 var obj;  
 obj=laysn.style;  
 obj.visibility='hidden';  
 }  
 </script>

 **8，子窗口打开，关闭父窗口**

 <script>  
 window.open('http://www.aspxhome.com/','','width=790,height=590');  
 window.opener=null;  
 window.close();  
 </script>