title: 如何在tomcat里为多个应用配置不同的访问端口
date: '2014-04-01 23:10:29'
updated: '2014-04-01 23:10:29'
tags: [CSDN迁移]
permalink: /articles/2014/04/01/1566182615296.html
---
打开tomcat安装目录，查看conf/server.xml

 <?xml version="1.0" encoding="UTF-8"?>

 <Server port="8005" shutdown="SHUTDOWN">

 <Listener className="org.apache.catalina.core.AprLifecycleListener" />  
 <Listener className="org.apache.catalina.mbeans.ServerLifecycleListener" />  
 <Listener className="org.apache.catalina.mbeans.GlobalResourcesLifecycleListener" />  
 <Listener className="org.apache.catalina.storeconfig.StoreConfigLifecycleListener"/>

 <GlobalNamingResources>  
 <Environment name="simpleValue" type="java.lang.Integer" value="30"/>  
 <Resource name="UserDatabase" auth="Container" type="org.apache.catalina.UserDatabase" description="User database that can be updated and saved" factory="org.apache.catalina.users.MemoryUserDatabaseFactory" pathname="conf/tomcat-users.xml" />  
 </GlobalNamingResources>  
 <Service name="Catalina">  
 <Connector port="**8099**" maxHttpHeaderSize="8192" maxThreads="150" minSpareThreads="25" maxSpareThreads="75" enableLookups="false" redirectPort="8443" acceptCount="100" connectionTimeout="20000" disableUploadTimeout="true" />  
 <Connector port="8009" enableLookups="false" redirectPort="8443" protocol="AJP/1.3" />  
 <Engine name="**Catalina**" defaultHost="localhost">  
 <Realm className="org.apache.catalina.realm.UserDatabaseRealm" resourceName="UserDatabase"/>  
 <Host name="localhost" **appBase="webapps"** unpackWARs="true" autoDeploy="true" xmlValidation="false" xmlNamespaceAware="false">  
 **<Context path="/demo2" docBase="D:/java/projects/demo2/WebRoot" reloadable="true" />  
** </Host>  
 </Engine>  
 </Service>  
 </Server>

 增加一个应用并设置访问端口为8098

 <Service name="Catalina1">  
 <Connector port="**8098**" maxHttpHeaderSize="8192" maxThreads="150" minSpareThreads="25" maxSpareThreads="75" enableLookups="false" redirectPort="8443" acceptCount="100" connectionTimeout="20000" disableUploadTimeout="true" />  
 <Connector port="8009" enableLookups="false" redirectPort="8443" protocol="AJP/1.3" />  
 <Engine name="**Catalina1**" defaultHost="localhost">  
 <Realm className="org.apache.catalina.realm.UserDatabaseRealm" resourceName="UserDatabase"/>  
 <Host name="localhost" **appBase="webapps"** unpackWARs="true" autoDeploy="true" xmlValidation="false" xmlNamespaceAware="false">  
 **<Context path="/demo1" docBase="D:/java/projects/demo1/WebRoot" reloadable="true" />**  
 </Host>  
 </Engine>  
 </Service>

 

 启动tomcat可以按如下地址访问：

 [http://localhost:8099/demo2/index.jsp](http://localhost:8099/demo2/index.jsp)

 [http://localhost:8098/demo1/index.jsp](http://localhost:8098/demo1/index.jsp)

 ※注意红色字体是要改的地方，另外2个应用里都存在 appBase=“webapps”，这个是tomcat下默认的目录，此目录下的所有应用均可以用这2个端口（8099、8098）访问，如果不想被2个端口都可以访问，可以修改appBase，如：appBase="webapps2",但要在tomcat安装目录下新建一个webapps2的目录。

 摘自：[http://blog.csdn.net/chouto/article/details/5710142](http://blog.csdn.net/chouto/article/details/5710142)