title: jdbctemplate
date: '2014-03-13 03:34:08'
updated: '2014-03-13 03:34:08'
tags: [CSDN迁移]
permalink: /articles/2014/03/13/1566182609558.html
---
[ ](http://creativecommons.org/licenses/by-sa/4.0/) 版权声明：本文为博主原创文章，遵循[ CC 4.0 by-sa ](http://creativecommons.org/licenses/by-sa/4.0/)版权协议，转载请附上原文出处链接和本声明。  本文链接：[https://blog.csdn.net/u012274449/article/details/21109069](https://blog.csdn.net/u012274449/article/details/21109069)   
    
   ```
    final User user = new User();  
    jdbcTemplate.query("SELECT * FROM USER WHERE user_id = ?",  
                        new Object[] {id},  
                        new RowCallbackHandler() {  
                            public void processRow(ResultSet rs) throws SQLException {  
                                user.setId(rs.getString("user_id"));  
                                user.setName(rs.getString("name"));  
                                user.setSex(rs.getString("sex").charAt(0));  
                                user.setAge(rs.getInt("age"));  
                            }  
                        });  
```
 查询方法

 


```
    class UserRowMapper implements RowMapper {  
        public Object mapRow(ResultSet rs, int index) throws SQLException {  
            User user = new User();  
      
            user.setId(rs.getString("user_id"));  
            user.setName(rs.getString("name"));  
            user.setSex(rs.getString("sex").charAt(0));  
            user.setAge(rs.getInt("age"));  
      
            return user;  
        }  
    }  
      
    public List findAllByRowMapperResultReader() {  
        String sql = "SELECT * FROM USER";  
        return jdbcTemplate.query(sql, new RowMapperResultReader(new UserRowMapper()));  
    }  
```
  
 在getUser(id)里面使用UserRowMapper 


```
    public User getUser(final String id) throws DataAccessException {  
        String sql = "SELECT * FROM USER WHERE user_id=?";  
        final Object[] params = new Object[] { id };  
        List list = jdbcTemplate.query(sql, params, new RowMapperResultReader(new UserRowMapper()));  
      
        return (User) list.get(0);  
    }  
```
1.增删改  
 org.springframework.jdbc.core.JdbcTemplate 类(必须指定数据源dataSource) 


```
    template.update("insert into web_person values(?,?,?)",Object[]);  




```

```
    template.update("insert into web_person values(?,?,?)",new PreparedStatementSetter(){ 匿名内部类 只能访问外部最终局部变量  
      
     public void setValues(PreparedStatement ps) throws SQLException {  
      ps.setInt(index++,3);  
    });  
```
  
  

```

```