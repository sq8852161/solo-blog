title: JdbcTemplate详解
date: '2014-03-04 21:06:52'
updated: '2014-03-04 21:06:52'
tags: [CSDN迁移]
permalink: /articles/2014/03/04/1566182606158.html
---
### 

 ### 1、JdbcTemplate操作数据库

 Spring对数据库的操作在jdbc上面做了深层次的封装，使用spring的注入功能，可以把DataSource注册到JdbcTemplate之中。同时，为了支持对properties文件的支持，spring提供了类似于EL表达式的方式，把dataSource.properties的文件参数引入到参数配置之中，<context:property-placeholderlocation="classpath:jdbc.properties" />。  
  实例代码如下：  
 提供数据源的相关配置信息：jdbc.properties  
 driverClassName=org.gjt.mm.mysql.Driver  
 url=jdbc\:mysql\://localhost\:3306/stanley?useUnicode\=true&characterEncoding\=UTF-8  
 username=root  
 password=123456  
 initialSize=1  
 maxActive=500  
 maxIdle=2  
 minIdle=1  
   
   
 提供spring的配置文件，将jdbc.properties与JdbcTemplate粘合起来的配置文件：beans.xml  
 <?xml  version="1.0"encoding="UTF-8"?>  
<beans  xmlns="http://www.springframework.org/schema/beans"  
 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  
 xmlns:context="http://www.springframework.org/schema/context"  
 xmlns:aop="http://www.springframework.org/schema/aop"  
 xmlns:tx="http://www.springframework.org/schema/tx"  
 xsi:schemaLocation="http://www.springframework.org/schema/beans  
 http://www.springframework.org/schema/beans/spring-beans-2.5.xsd  
 http://www.springframework.org/schema/contexthttp://www.springframework.org/schema/context/spring-context-2.5.xsd  
 http://www.springframework.org/schema/aophttp://www.springframework.org/schema/aop/spring-aop-2.5.xsd  
 http://www.springframework.org/schema/txhttp://www.springframework.org/schema/tx/spring-tx-2.5.xsd">  
  
 <context:property-placeholderlocation="classpath:jdbc.properties"/>  
 <beanid="dataSource" class="org.apache.commons.dbcp.BasicDataSource"destroy-method="close">  
 <property name="driverClassName" value="${driverClassName}"/>  
 <property name="url"value="${url}"/>  
 <property name="username"value="${username}"/>  
 <property name="password"value="${password}"/>  
 <!--连接池启动时的初始值 -->  
 <property name="initialSize"value="${initialSize}"/>  
 <!-- 连接池的最大值-->  
 <property name="maxActive"value="${maxActive}"/>  
 <!-- 最大空闲值.当经过一个高峰时间后，连接池可以慢慢将已经用不到的连接慢慢释放一部分，一直减少到maxIdle为止-->  
 <property name="maxIdle"value="${maxIdle}"/>  
 <!-- 最小空闲值.当空闲的连接数少于阀值时，连接池就会预申请去一些连接，以免洪峰来时来不及申请-->  
 <property name="minIdle"value="${minIdle}"/>  
 </bean>  
  
 <beanid="txManager" class="org.springframework.jdbc.datasource.DataSourceTransactionManager">  
 <propertyname="dataSource" ref="dataSource"/>  
 </bean>  
  
 <aop:config>