title: Eclipse Java注释模板设置详解
date: '2014-04-21 18:58:36'
updated: '2014-04-21 18:58:36'
tags: [CSDN迁移]
permalink: /articles/2014/04/21/1566182614809.html
---
设置注释模板的入口： Window->Preference->Java->Code Style->Code Template 然后展开Comments节点就是所有需设置注释的元素啦。现就每一个元素逐一介绍：

 文件(Files)注释标签：

 /**   
 * @Title: ${file_name}   
 * @Package ${package_name}   
 * @Description: ${todo}(用一句话描述该文件做什么)   
 * @author A18ccms A18ccms_gmail_com   
 * @date ${date} ${time}   
 * @version V1.0   
 */

 类型(Types)注释标签（类的注释）：

 /**   
 * @ClassName: ${type_name}   
 * @Description: ${todo}(这里用一句话描述这个类的作用)   
 * @author A18ccms a18ccms_gmail_com   
 * @date ${date} ${time}   
 *   
 * ${tags}   
 */

 字段(Fields)注释标签：

 /**   
 * @Fields ${field} : ${todo}(用一句话描述这个变量表示什么)   
 */   
 构造函数标签：

 /**   
 * <p>Title: </p>   
 * <p>Description: </p>   
 * ${tags}   
 */

 方法(Constructor & Methods)标签：

 /**   
 * @Title: ${enclosing_method}   
 * @Description: ${todo}(这里用一句话描述这个方法的作用)   
 * @param ${tags} 设定文件   
 * @return ${return_type} 返回类型   
 * @throws   
 */

 覆盖方法(Overriding Methods)标签：

 /* (非 Javadoc)   
 * <p>Title: ${enclosing_method}</p>   
 * <p>Description: </p>   
 * ${tags}   
 * ${see_to_overridden}   
 */

 代表方法(Delegate Methods)标签：

 /**   
 * ${tags}   
 * ${see_to_target}   
 */   
 getter方法标签：

 /**   
 * @return ${bare_field_name}   
 */

 setter方法标签：

 /**   
 * @param ${param} 要设置的 ${bare_field_name}   
 */

 简单模板例子：   
 <?xml version="1.0" encoding="UTF-8"?><templates><template autoinsert="true" context="fieldcomment_context" deleted="false" description="字段的注释" enabled="true" id="org.eclipse.jdt.ui.text.codetemplates.fieldcomment" name="fieldcomment">/**   
 * @Fields ${field} : ${todo}(用一句话描述这个变量表示什么)   
 */   
 </template><template autoinsert="true" context="gettercomment_context" deleted="false" description="getter 方法的注释" enabled="true" id="org.eclipse.jdt.ui.text.codetemplates.gettercomment" name="gettercomment">/**   
 * @return ${bare_field_name}   
 */   
 </template><template autoinsert="true" context="constructorcomment_context" deleted="false" description="创建的构造函数的注释" enabled="true" id="org.eclipse.jdt.ui.text.codetemplates.constructorcomment" name="constructorcomment">/**   
 * <p>Title:${file_name} </p>   
 * <p>Description: 构造函数</p>   
 * ${tags}   
 */   
 </template><template autoinsert="true" context="filecomment_context" deleted="false" description="已创建的 Java 文件的注释" enabled="true" id="org.eclipse.jdt.ui.text.codetemplates.filecomment" name="filecomment">/**   
 * @Title: ${file_name}   
 * @Package ${package_name}   
 * @Description: ${todo}(用一句话描述该文件做什么)   
 * @author DAIGUANGJIU   
 * @date ${date} ${time}   
 * @version V1.0   
 */   
 </template><template autoinsert="true" context="settercomment_context" deleted="false" description="setter 方法的注释" enabled="true" id="org.eclipse.jdt.ui.text.codetemplates.settercomment" name="settercomment">/**   
 * @param ${param} 要设置的 ${bare_field_name}   
 */</template><template autoinsert="true" context="typecomment_context" deleted="false" description="创建的类型的注释" enabled="true" id="org.eclipse.jdt.ui.text.codetemplates.typecomment" name="typecomment">/**   
 * @author ${user}   
 *   
 * ${tags}   
 */</template><template autoinsert="true" context="delegatecomment_context" deleted="false" description="代表方法的注释" enabled="true" id="org.eclipse.jdt.ui.text.codetemplates.delegatecomment" name="delegatecomment">/**   
 * ${tags}   
 * ${see_to_target}   
 */</template><template autoinsert="true" context="overridecomment_context" deleted="false" description="覆盖方法的注释" enabled="true" id="org.eclipse.jdt.ui.text.codetemplates.overridecomment" name="overridecomment">/** (非 Javadoc)   
 * <p>Title: ${enclosing_method}</p>   
 * <p>Description: </p>   
 * ${tags}   
 * ${see_to_overridden}   
 */</template><template autoinsert="true" context="methodcomment_context" deleted="false" description="非覆盖方法的注释" enabled="true" id="org.eclipse.jdt.ui.text.codetemplates.methodcomment" name="methodcomment">/**   
 * ${tags}   
 */</template></templa   
 <?xml version="1.0" encoding="UTF-8"?><templates><template autoinsert="true" context="fieldcomment_context" deleted="false" description="字段的注释" enabled="true" id="org.eclipse.jdt.ui.text.codetemplates.fieldcomment" name="fieldcomment">/**   
 * @Fields ${field} : ${todo}(用一句话描述这个变量表示什么)   
 */   
 </template><template autoinsert="true" context="gettercomment_context" deleted="false" description="getter 方法的注释" enabled="true" id="org.eclipse.jdt.ui.text.codetemplates.gettercomment" name="gettercomment">/**   
 * @return ${bare_field_name}   
 */   
 </template><template autoinsert="true" context="constructorcomment_context" deleted="false" description="创建的构造函数的注释" enabled="true" id="org.eclipse.jdt.ui.text.codetemplates.constructorcomment" name="constructorcomment">/**   
 * <p>Title:${file_name} </p>   
 * <p>Description: 构造函数</p>   
 * ${tags}   
 */   
 </template><template autoinsert="true" context="filecomment_context" deleted="false" description="已创建的 Java 文件的注释" enabled="true" id="org.eclipse.jdt.ui.text.codetemplates.filecomment" name="filecomment">/**   
 * @Title: ${file_name}   
 * @Package ${package_name}   
 * @Description: ${todo}(用一句话描述该文件做什么)   
 * @author DAIGUANGJIU   
 * @date ${date} ${time}   
 * @version V1.0   
 */   
 </template><template autoinsert="true" context="settercomment_context" deleted="false" description="setter 方法的注释" enabled="true" id="org.eclipse.jdt.ui.text.codetemplates.settercomment" name="settercomment">/**   
 * @param ${param} 要设置的 ${bare_field_name}   
 */</template><template autoinsert="true" context="typecomment_context" deleted="false" description="创建的类型的注释" enabled="true" id="org.eclipse.jdt.ui.text.codetemplates.typecomment" name="typecomment">/**   
 * @author ${user}   
 *   
 * ${tags}   
 */</template><template autoinsert="true" context="delegatecomment_context" deleted="false" description="代表方法的注释" enabled="true" id="org.eclipse.jdt.ui.text.codetemplates.delegatecomment" name="delegatecomment">/**   
 * ${tags}   
 * ${see_to_target}   
 */</template><template autoinsert="true" context="overridecomment_context" deleted="false" description="覆盖方法的注释" enabled="true" id="org.eclipse.jdt.ui.text.codetemplates.overridecomment" name="overridecomment">/** (非 Javadoc)   
 * <p>Title: ${enclosing_method}</p>   
 * <p>Description: </p>   
 * ${tags}   
 * ${see_to_overridden}   
 */</template><template autoinsert="true" context="methodcomment_context" deleted="false" description="非覆盖方法的注释" enabled="true" id="org.eclipse.jdt.ui.text.codetemplates.methodcomment" name="methodcomment">/**   
 * ${tags}   
 */</template></templa

 例子2：   
 <?xml version="1.0" encoding="UTF-8"?>   
 <templates>   
 <template   
 autoinsert="false"   
 context="constructorcomment_context"   
 deleted="false"   
 description="Comment for created constructors"   
 enabled="true"   
 id="org.eclipse.jdt.ui.text.codetemplates.constructorcomment"   
 name="constructorcomment">   
 /**   
 * 创建一个新的实例 ${enclosing_type}.   
 *   
 * ${tags}   
 */   
 </template>   
 <template   
 autoinsert="true"   
 context="settercomment_context"   
 deleted="false"   
 description="Comment for setter method"   
 enabled="true"   
 id="org.eclipse.jdt.ui.text.codetemplates.settercomment"   
 name="settercomment">   
 /**   
 * @param ${param} the ${bare_field_name} to set   
 */   
 </template>   
 <template   
 autoinsert="false"   
 context="methodcomment_context"   
 deleted="false"   
 description="Comment for non-overriding methods"   
 enabled="true"   
 id="org.eclipse.jdt.ui.text.codetemplates.methodcomment"   
 name="methodcomment">   
 /**   
 * 此方法描述的是：   
 * @author: wangxiongdx@163.com   
 * @version: ${date} ${time}   
 */   
 </template>   
 <template   
 autoinsert="true"   
 context="delegatecomment_context"   
 deleted="false"   
 description="Comment for delegate methods"   
 enabled="true"   
 id="org.eclipse.jdt.ui.text.codetemplates.delegatecomment"   
 name="delegatecomment">   
 /**   
 * ${tags}   
 * ${see_to_target}   
 */   
 </template>   
 <template   
 autoinsert="false"   
 context="filecomment_context"   
 deleted="false"   
 description="Comment for created Java files"   
 enabled="true"   
 id="org.eclipse.jdt.ui.text.codetemplates.filecomment"   
 name="filecomment">   
 /**   
 * 文件名：${file_name}   
 *   
 * 版本信息：   
 * 日期：${date}   
 * Copyright 足下 Corporation ${year}   
 * 版权所有   
 *   
 */   
 </template>   
 <template   
 autoinsert="false"   
 context="gettercomment_context"   
 deleted="false"   
 description="Comment for getter method"   
 enabled="true"   
 id="org.eclipse.jdt.ui.text.codetemplates.gettercomment"   
 name="gettercomment">   
 /**   
 * ${bare_field_name}   
 *   
 * @return the ${bare_field_name}   
 * @since CodingExample Ver(编码范例查看) 1.0   
 */   
 </template>   
 <template   
 autoinsert="true"   
 context="overridecomment_context"   
 deleted="false"   
 description="Comment for overriding methods"   
 enabled="true"   
 id="org.eclipse.jdt.ui.text.codetemplates.overridecomment"   
 name="overridecomment">   
 /* (non-Javadoc)   
 * ${see_to_overridden}   
 */   
 </template>   
 <template   
 autoinsert="false"   
 context="fieldcomment_context"   
 deleted="false"   
 description="Comment for fields"   
 enabled="true"   
 id="org.eclipse.jdt.ui.text.codetemplates.fieldcomment"   
 name="fieldcomment">   
 /**   
 * ${field}:${todo}（用一句话描述这个变量表示什么）   
 *   
 * @since Ver 1.1   
 */   
 </template>   
 <template   
 autoinsert="false"   
 context="typecomment_context"   
 deleted="false"   
 description="Comment for created types"   
 enabled="true"   
 id="org.eclipse.jdt.ui.text.codetemplates.typecomment"   
 name="typecomment">   
 /**   
 * 此类描述的是：   
 * @author: wangxiongdx@163.com   
 * @version: ${date} ${time}   
 */   
 </template>   
 </templates>   
 <?xml version="1.0" encoding="UTF-8"?>   
 <templates>   
 <template   
 autoinsert="false"   
 context="constructorcomment_context"   
 deleted="false"   
 description="Comment for created constructors"   
 enabled="true"   
 id="org.eclipse.jdt.ui.text.codetemplates.constructorcomment"   
 name="constructorcomment">   
 /**   
 * 创建一个新的实例 ${enclosing_type}.   
 *   
 * ${tags}   
 */   
 </template>   
 <template   
 autoinsert="true"   
 context="settercomment_context"   
 deleted="false"   
 description="Comment for setter method"   
 enabled="true"   
 id="org.eclipse.jdt.ui.text.codetemplates.settercomment"   
 name="settercomment">   
 /**   
 * @param ${param} the ${bare_field_name} to set   
 */   
 </template>   
 <template   
 autoinsert="false"   
 context="methodcomment_context"   
 deleted="false"   
 description="Comment for non-overriding methods"   
 enabled="true"   
 id="org.eclipse.jdt.ui.text.codetemplates.methodcomment"   
 name="methodcomment">   
 /**   
 * 此方法描述的是：   
 * @author: wangxiongdx@163.com   
 * @version: ${date} ${time}   
 */   
 </template>   
 <template   
 autoinsert="true"   
 context="delegatecomment_context"   
 deleted="false"   
 description="Comment for delegate methods"   
 enabled="true"   
 id="org.eclipse.jdt.ui.text.codetemplates.delegatecomment"   
 name="delegatecomment">   
 /**   
 * ${tags}   
 * ${see_to_target}   
 */   
 </template>   
 <template   
 autoinsert="false"   
 context="filecomment_context"   
 deleted="false"   
 description="Comment for created Java files"   
 enabled="true"   
 id="org.eclipse.jdt.ui.text.codetemplates.filecomment"   
 name="filecomment">   
 /**   
 * 文件名：${file_name}   
 *   
 * 版本信息：   
 * 日期：${date}   
 * Copyright 足下 Corporation ${year}   
 * 版权所有   
 *   
 */   
 </template>   
 <template   
 autoinsert="false"   
 context="gettercomment_context"   
 deleted="false"   
 description="Comment for getter method"   
 enabled="true"   
 id="org.eclipse.jdt.ui.text.codetemplates.gettercomment"   
 name="gettercomment">   
 /**   
 * ${bare_field_name}   
 *   
 * @return the ${bare_field_name}   
 * @since CodingExample Ver(编码范例查看) 1.0   
 */   
 </template>

 <template   
 autoinsert="true"   
 context="overridecomment_context"   
 deleted="false"   
 description="Comment for overriding methods"   
 enabled="true"   
 id="org.eclipse.jdt.ui.text.codetemplates.overridecomment"   
 name="overridecomment">   
 /* (non-Javadoc)   
 * ${see_to_overridden}   
 */   
 </template>   
 <template   
 autoinsert="false"   
 context="fieldcomment_context"   
 deleted="false"   
 description="Comment for fields"   
 enabled="true"   
 id="org.eclipse.jdt.ui.text.codetemplates.fieldcomment"   
 name="fieldcomment">   
 /**   
 * ${field}:${todo}（用一句话描述这个变量表示什么）   
 *   
 * @since Ver 1.1   
 */   
 </template>   
 <template   
 autoinsert="false"   
 context="typecomment_context"   
 deleted="false"   
 description="Comment for created types"   
 enabled="true"   
 id="org.eclipse.jdt.ui.text.codetemplates.typecomment"   
 name="typecomment">   
 /**   
 * 此类描述的是：   
 * @author: wangxiongdx@163.com   
 * @version: ${date} ${time}   
 */   
 </template>   
 </templates>