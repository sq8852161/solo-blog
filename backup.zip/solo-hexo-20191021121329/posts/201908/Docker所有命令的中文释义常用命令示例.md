title: Docker所有命令的中文释义+常用命令示例
date: '2019-08-15 14:44:05'
updated: '2019-09-14 11:49:37'
tags: [Docker]
permalink: /articles/2019/08/15/1565851445410.html
---
![](https://img.hacpai.com/bing/20190528.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)
```shell
docker ps -a  //查看所有容器状态
docker pull 拉取
docker exec -it containerID /bin/bash   进入容器交互  containerID:镜像ID
docker exec -it 容器名 /bin/sh
docker cp mysql-docker:/etc/mysql/conf.d/mysql.cnf /dockerData/mysql/
docker cp /dockerData/mysql/my.cnf mysql-docker:/etc/mysql/my.cnf
docker logs solo //查看应用“solo”的日志

  attach	将本地标准输入，输出和错误流附加到正在运行的容器
  build	从Dockerfile构建映像
  commit	从容器的更改中创建新图像
  cp		在容器和本地文件系统之间复制文件/文件夹
  create	创建一个新容器
  diff		检查容器文件系统上的文件或目录的更改
  events	从服务器获取实时事件
  exec	在正在运行的容器中运行命令
  export	将容器的文件系统导出为tar存档
  history	显示图像的历史记录
  images   列出图像
  import	从tarball导入内容以创建文件系统映像
  info	显示系统范围的信息
  inspect     返回Docker对象的低级信息
  kill		杀死一个或多个正在运行的容器
  load	从tar存档或STDIN加载图像
  login       登录Docker注册表
  logout      从Docker注册表注销
  logs	获取容器的日志
  pause       暂停一个或多个容器中的所有进程
  port	列出端口映射或容器的特定映射
  ps		列出容器
  pull	从注册表中提取图像或存储库
  push	将映像或存储库推送到注册表
  rename      重命名容器
  restart	重新启动一个或多个容器
  rm		移除一个或多个容器
  rmi		删除一张或多张图像
  run		在新容器中运行命令
  save  	将一个或多个图像保存到tar存档（默认情况下流式传输到STDOUT）
  search	在Docker Hub中搜索图像
  start	启动一个或多个已停止的容器
  stats	显示容器资源使用情况统计信息的实时流
  stop        一个或多个正在运行的容器
  tag		创建引用SOURCE_IMAGE的标记TARGET_IMAGE
  top		显示容器的运行进程
  unause	取消暂停一个或多个容器中的所有进程
  update	更新一个或多个容器的配置
  version	显示Docker版本信息
  wait        阻止，直到一个或多个容器停止，然后打印退出代码
```
