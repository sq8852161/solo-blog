title: 用JS改变的元素CSS样式
date: '2014-04-10 18:49:45'
updated: '2014-04-10 18:49:45'
tags: [CSDN迁移]
permalink: /articles/2014/04/10/1566182608700.html
---
CSS样式的引用有3种方式：style引用、class引用、id引用，所以js改变元素的样式我们也分3种来说。

 1.js改变由style方式引用的样式：  
 方法一：document.divs.style.cssText="border:1px solid #000000;color:#FF0000";  
 方法二：document.divs.setAttribute("style","border:1px solid #000000;color:#FF0000");  
  
 其中，divs是要改变样式元素的name。

 2.js改变由class方式引用的样式：  
 方法一：document.divs.className='divs1';  
 方法二：document.divs.setAttribute("class","divs1");  
  
 其中，divs是要改变样式元素的name。

 3.js改变由id方式引用的样式：  
 方法二：document.divs.setAttribute("id","divs1");  
  
 其中，divs是要改变样式元素的name。