title: Cloudera Manager安装时配置mysql数据库
date: '2019-08-20 08:38:39'
updated: '2019-08-20 08:38:39'
tags: [ClouderaManager, Mysql, 大数据]
permalink: /articles/2019/08/20/1566261519103.html
---

在https://dev.mysql.com/downloads/file/?id=484537
下载mysql 5.7版

在各个节点上进行MySQL的旧版本卸载：
rpm -qa | grep  MySQL
rpm -qa | grep  mariadb
用以下命令卸载查出的包
rpm -e --nodeps mariadb-libs-5.5.56-2.el7.x86_64
sudo rpm -e mariadb-libs-5.5.56-2.el7.x86_64 --nodeps

 
将mysql驱动放到/usr/shart/java中，并改名
mv mysql-connector-java-5.1.30.jar  mysql-connector-java.jar
传输到各个节点
scp mysql-connector-java.jar root@rs-slave04:/usr/share/java


上传mysql安装包
tar -xvf 解压mysql安装包
tar -xvf mysql-5.7.25-1.el7.x86_64.rpm-bundle.tar 

rpm -ivh mysql*.rpm 安装所有mysql
rpm -ivh mysql-community-common-5.7.25-1.el7.x86_64.rpm
rpm -ivh mysql-community-libs-5.7.25-1.el7.x86_64.rpm
rpm -ivh mysql-community-client-5.7.25-1.el7.x86_64.rpm
rpm -ivh  mysql-community-server-5.7.25-1.el7.x86_64.rpm
rpm -ivh mysql-community-libs-compat-5.7.25-1.el7.x86_64.rpm 
service mysqld start
找出mysql安装默认生成的密码：
cat /var/log/mysqld.log |grep password

2019-02-27T14:58:56.989712Z 1 [Note] A temporary password is generated for root@localhost: oY7i+lGEBd)w


查看密码
grep 'temporary password' /var/log/mysqld.log 
2016-07-08T02:25:46.311098Z 1 [Note] A temporary password is generated for root@localhost: MtPqF0/oN5zo
其中“MtPqF0/oN5zo”就为我们要找的初始密码
修改用户root密码；

登陆mysql：
mysql -uroot -p 
oY7i+lGEBd)w

修改mysql密码验证复杂度校验 以下语句谁为按长度校验
set global validate_password_policy=0;
以下语句设置最小可以密码为一位
set global validate_password_length=1;

在MySQL中修改root密码：
set PASSWORD=PASSWORD('123456');


开启mysql远程连接
grant all on *.* to 'root'@'%' identified by '123456' with grant option;

建立各个组件的数据库，及用户名密码

CREATE DATABASE hive DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
GRANT ALL ON hive.* TO 'hive'@'%' IDENTIFIED BY 'hive@123';

CREATE DATABASE scm DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
GRANT ALL ON scm.* TO 'scm'@'%' IDENTIFIED BY 'scm@123';
CREATE DATABASE amon DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
GRANT ALL ON amon.* TO 'amon'@'%' IDENTIFIED BY ' amon@123';
CREATE DATABASE rman DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
GRANT ALL ON rman.* TO 'rman'@'%' IDENTIFIED BY 'rman@123';
CREATE DATABASE hue DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
GRANT ALL ON hue.* TO 'hue'@'%' IDENTIFIED BY 'hue@123';
CREATE DATABASE metastore DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
GRANT ALL ON metastore.* TO 'metastore'@'%' IDENTIFIED BY 'metastore@123';
CREATE DATABASE sentry DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
GRANT ALL ON sentry.* TO 'sentry'@'%' IDENTIFIED BY 'sentry@123';
CREATE DATABASE nav DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
GRANT ALL ON nav.* TO 'nav'@'%' IDENTIFIED BY 'nav@123';
CREATE DATABASE navms DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
GRANT ALL ON navms.* TO 'navms'@'%' IDENTIFIED BY 'navms@123';
CREATE DATABASE oozie DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
GRANT ALL ON oozie.* TO 'oozie'@'%' IDENTIFIED BY 'oozie@123';

刷新权限：
flush privileges;

查询修改my.conf
find / -name my.cnf
备份my.cnf
mv my.cnf my.cnf_bak
nano my.cnf
添加以下内容：
[mysqld]
datadir=/var/lib/mysql
socket=/var/lib/mysql/mysql.sock
transaction-isolation = READ-COMMITTED
# Disabling symbolic-links is recommended to prevent assorted security risks;
# to do so, uncomment this line:
symbolic-links = 0

key_buffer_size = 32M
max_allowed_packet = 32M
thread_stack = 256K
thread_cache_size = 64
query_cache_limit = 8M
query_cache_size = 64M
query_cache_type = 1

max_connections = 550
#expire_logs_days = 10
#max_binlog_size = 100M

#log_bin should be on a disk with enough free space.
#Replace '/var/lib/mysql/mysql_binary_log' with an appropriate path for your
#system and chown the specified folder to the mysql user.
log_bin=/var/lib/mysql/mysql_binary_log

#In later versions of MySQL, if you enable the binary log and do not set
#a server_id, MySQL will not start. The server_id must be unique within
#the replicating group.
server_id=1

binlog_format = mixed

read_buffer_size = 2M
read_rnd_buffer_size = 16M
sort_buffer_size = 8M
join_buffer_size = 8M

# InnoDB settings
innodb_file_per_table = 1
innodb_flush_log_at_trx_commit  = 2
innodb_log_buffer_size = 64M
innodb_buffer_pool_size = 4G
innodb_thread_concurrency = 8
innodb_flush_method = O_DIRECT
innodb_log_file_size = 512M

[mysqld_safe]
log-error=/var/log/mysqld.log
pid-file=/var/run/mysqld/mysqld.pid

sql_mode=STRICT_ALL_TABLES

然后重启MySQL服务器
service mysqld restart


删除此文件：
sudo rm /etc/cloudera-scm-server/db.mgmt.properties


必须执行此命令，才能使cdh使用MySQL数据库
sudo /usr/share/cmf/schema/scm_prepare_database.sh -h 192.168.0.130 mysql scm scm
密码scm@123


安装CDH

停止cloudera内置数据库服务
service cloudera-scm-server-db stop








