title: 在线数据挖掘工具tipdm部署流程
date: '2019-09-02 17:34:50'
updated: '2019-09-03 17:00:41'
tags: [数据挖掘, 大数据, tipdm]
permalink: /articles/2019/09/02/1567416890451.html
---
![](https://img.hacpai.com/bing/20190712.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)


**python环境必须为linux环境**
### 1，安装python3.6
```
yum install python-devel postgresql-devel
yum search python3
yum install python36u-devel.x86_64
```

### 2，按照python列表安装插件
创建虚拟python环境
```
python3.6 -m venv venv

source ./venv/bin/activate
pip install numpy==1.16.4 -i http://pypi.douban.com/simple --trusted-host pypi.douban.com
pip install arch==4.4.1 -i http://pypi.douban.com/simple --trusted-host pypi.douban.com
pip install docx==0.2.4 -i http://pypi.douban.com/simple --trusted-host pypi.douban.com
pip install gensim==3.6.0 -i http://pypi.douban.com/simple --trusted-host pypi.douban.com
pip install graphviz==0.10.1 -i http://pypi.douban.com/simple --trusted-host pypi.douban.com
pip install jieba==0.38 -i http://pypi.douban.com/simple --trusted-host pypi.douban.com
pip install jieba-fast==0.53 -i http://pypi.douban.com/simple --trusted-host pypi.douban.com
pip install matplotlib==2.2.2 -i http://pypi.douban.com/simple --trusted-host pypi.douban.com
pip install pandas==0.23.4 -i http://pypi.douban.com/simple --trusted-host pypi.douban.com
pip install pdfminer3k==1.3.1 -i http://pypi.douban.com/simple --trusted-host pypi.douban.com
pip install pyclust==0.2.0 -i http://pypi.douban.com/simple --trusted-host pypi.douban.com
pip install pydot==1.2.4 -i http://pypi.douban.com/simple --trusted-host pypi.douban.com
pip install python-docx==0.8.10 -i http://pypi.douban.com/simple --trusted-host pypi.douban.com
pip install scikit-learn==0.19.1 -i http://pypi.douban.com/simple --trusted-host pypi.douban.com
pip install scipy==0.19.1 -i http://pypi.douban.com/simple --trusted-host pypi.douban.com
pip install SQLAlchemy==1.2.0 -i http://pypi.douban.com/simple --trusted-host pypi.douban.com
pip install scikit-learn==0.19.1 -i http://pypi.douban.com/simple --trusted-host pypi.douban.com
pip install statsmodels==0.9.0 -i http://pypi.douban.com/simple --trusted-host pypi.douban.com
pip install tensorflow==1.14.0 -i http://pypi.douban.com/simple --trusted-host pypi.douban.com
pip install thulac==0.2.0 -i http://pypi.douban.com/simple --trusted-host pypi.douban.com
pip install wordcloud==1.5.0 -i http://pypi.douban.com/simple --trusted-host pypi.douban.com
pip install psycopg2 -i http://pypi.douban.com/simple --trusted-host pypi.douban.com
pip install joblib -i http://pypi.douban.com/simple --trusted-host pypi.douban.com
pip install matplot -i http://pypi.douban.com/simple --trusted-host pypi.douban.com
```


### 3，安装postgresql9.6，并使用shell脚本载入初始化数据库
```
tipdm=# \i D:/java/tipdm/TipDM/backend/tipdm-server/src/main/resources/sql/initData.sql
将表权限赋给admin(重要，不然后续查询会报错)
GRANT ALL ON test TO admin
修改postgresql的外部访问数据库接口
D:\Program Files\PostgreSQL\9.6\data
ip为访问方的ip
host    all             all             192.168.0.0/32        md5

linux下
vi /var/lib/pgsql/9.6/data/pg_hba.conf
```


### 4，安装redais
```
https://www.cnblogs.com/suanshun/p/7699084.html
```
### 5，idea加载平台源码
### 6，idea修改tomcat的端口及文件名 为 8088/dmserver
### 7，修改database.properties，加入postgresql数据库信息
### 8，修改redis.properties，加入redis密码信息
### 9，修改PyConnectionPool.xml ，修改pyserver的地址
```
<?xml version="1.0" encoding="UTF-8"?>
<PyConnectionPool>
    <PyConfiguration>
        <!-- 可配置多个PyServer 目标服务器，使用ssh连接-->
        <PyServer host="192.168.0.164" sshuser="root" sshpwd="root" sshport="22"/>
    </PyConfiguration>
</PyConnectionPool>
``` 

### 10,配置tipdm静态文件
```
server/src/main/resources/sysconfig/system.properties
#根目录（集群模式下为挂载的目录，修改ROOT_DIR为当前系统示例文件绝对路径）部署到linux上要做相应修改
ROOT_DIR = D:/java/tipdm/TipDM/templates
ROOT_DIR =/soft/templates  //这是linux下的路径
#DataX安装目录（需要安装DataX插件）
dataX.home = /soft/datax（linux路径）
```
### 11，启动用户校验微服务。
直接打开微服务的main文件，点击启动就可以了。

**以上步骤配置完成后，其实已经可以在开发环境下运行了。
如果需要在服务器上部署的话，请看以下步骤**


### 12，tomcat配置server.xml，配置前端包一起启动。配置完成创建webapp1文件夹，并将前端打的包dist中的文件放入此文件夹。
```
 <Service name="Catalina">

    <Connector port="8088" protocol="HTTP/1.1"
               connectionTimeout="20000"
               redirectPort="8443" />

......
<Service name="Catalina1">
<!-- 此端口为8089，其他项目端口不能有冲突 -->
    <Connector port="8089" protocol="HTTP/1.1"
               connectionTimeout="20000"
               redirectPort="8445" />
    <Engine name="Catalina1" defaultHost="localhost">
      <Realm className="org.apache.catalina.realm.LockOutRealm">
        <Realm className="org.apache.catalina.realm.UserDatabaseRealm"
               resourceName="UserDatabase"/>
      </Realm>
      <Host name="localhost"  appBase="webapp1" unpackWARs="true" autoDeploy="true">
        <!-- 配置：项目名，项目路径 -->
                <Context path="" docBase="" reloadable="false" />
        <Valve className="org.apache.catalina.valves.AccessLogValve" directory="logs"
               prefix="localhost_access_log." suffix=".txt"
               pattern="%h %l %u %t "%r" %s %b" />
      </Host>
    </Engine>
  </Service>
```


### 13，前端配置，frontend/config/index
```
dev: {

    // Paths
    assetsSubDirectory: 'static',
    assetsPublicPath: '/',
    proxyTable: {},

    // Various Dev Server settings
    host: '192.168.0.164', // can be overwritten by process.env.HOST
    port: 8089, // can be overwritten by process.env.PORT, if port is in use, a free one will be determined
    autoOpenBrowser: true,
    errorOverlay: true,
    notifyOnErrors: true,
    poll: false, // https://webpack.js.org/configuration/dev-server/#devserver-watchoptions-
```



### 14,打包前端，生成dist，将生成的文件放入tomcat新做的webapp1文件夹内
```
npm run build 
```
### 15 将后端文件打包
按https://gitee.com/guangzhou_TipDM_intelligence_devp/TipDM
上的步骤打包，放入服务器tomcat的webapp中。
这样就能做到，一个tomcat启动前后端。

### 16，服务器登录校验微服务脚本
启动脚本
```
#!/bin/sh
jarname='/soft/apache-tomcat-9.0.22/webapps/mock-oauth-server-1.0-SNAPSHOT.jar'
nohup java -jar $jarname --spring.profiles.active=dev -server -Xms512m -Xmx1024m -Xss256k > ./run.log 2>&1 &
echo "start successed!!!"
tail -50f run.log
```
重启脚本
```
#!/bin/sh
jarname='/soft/apache-tomcat-9.0.22/webapps/mock-oauth-server-1.0-SNAPSHOT.jar'
pid=`ps aux | grep $jarname | grep -v grep | awk '{print $2}'`
echo $pid
kill -9 $pid
nohup java -jar $jarname --spring.profiles.active=dev -server -Xms512m -Xmx1024m -Xss256k 8 2>&1 &
echo "start successed!!!"
tail -50f run.log                                                                                                                                                                                                                                                                                                                         
```                       
### 17，解决python字体问题

https://blog.csdn.net/mr_muli/article/details/89485619/tmp/pyserve/venv/lib64/python3.6/site-packages/matplotlib/mpl-data/matplotlibrc

### 18，在服务器上安装redis
**重要**
详情请参考

[https://blog.csdn.net/qq_39135287/article/details/83474865](https://blog.csdn.net/qq_39135287/article/details/83474865)



ps:一些命令
```
netstat -ntlp   //查看当前所有tcp端口·
netstat -ntulp |grep 80   //查看所有80端口使用情况·
netstat -an | grep 3306   //查看所有3306端口使用情况·
```
在服务器上 
```
/soft 

tail -n 100 catalina.2019-08-15.log  //查看日志后100行
```
