title: 教你如何将Access数据库移植到SQL Server
date: '2014-04-01 21:37:34'
updated: '2014-04-01 21:37:34'
tags: [CSDN迁移]
permalink: /articles/2014/04/01/1566182606992.html
---
随着用户对于企业级高性能数据库的需求的增长，用户时常要从Microsoft Access Jet引擎的文件-服务器环境下转换到MicrosoftSQL Server的客户-服务器环境。Microsoft Office 2000中的Access 2000 Upsizing Wizard可实现将数据表和查询转移到SQLServer 7.0中。如果您用的是Access的较早的版本，您可以先将它升级为Access 2000，然后再使用其中的Upsizing Wizard，从而将您的应用移植到SQL Server中。  
  
  
 如果您并不太愿意采用Access 2000 和Upsizing Wizard来实现移植，本文可以作为将Access 2000移植到SQL Server的一个指南。转移一个Access上的应用首先需要将数据转移到SQL Server，然后将查询转移进数据库，或是转移为SQL文件以备稍后执行。最后要采取的步骤是移植应用程序。  
  
  
 数据库移植中用到的SQLServer 工具  
  
  
 SQL Server管理器(SQL Server Enterprise Manager)  
  
  
 SQL Server管理器允许对SQL Server以及SQL Server中的对象进行企业级的配置和管理。SQL Server管理器提供一个强有力的scheduling引擎，高度的容错力和一个嵌入式的复制管理界面。  
 使用SQL Server管理器可以实现以下功能：   
  
  
 管理连接和用户许可   
  
  
 创建脚本程序   
  
  
 管理SQL Server对象的备份   
  
  
 备份数据和事务处理日志   
  
  
 管理表、视图、存储过程、触发器、索引、规则、默认值以及用户定义的数据类型   
  
  
 建立全文本索引、数据库图表和数据库维护计划   
  
  
 输入和输出数据   
  
  
 转换数据   
  
  
 执行各种网络管理任务   
  
  
 在以Microsoft Windows NT为操作系统的计算机中，SQL Server Manager由SQL Server Setup进行安装，并被默认为服务器组件，而在运行着Windows NT 和Microsoft Windows 95的机器上，它将被默认为客户方组件。您将从SQL Server Manager的图形用户界面中启动数据转移服务(DTS，Data Transformation Services)。数据转移服务(DataTransformation Services ，DTS),数据转移服务允许您在多种异构数据源之间输入和输出数据，这些数据源采用基于数据库的OLE体系结构;或在使用SQLServer 7.0的多个计算机之间转移数据库和数据库对象;您还可以通过运用数据转移服务，更便捷地在一个在线事务处理系统(OLTP)中建立数据仓库和数据中心。DTS Wizard允许您交互地创建DTS包，通过OLE DB和ODBC来输入、输出、验证和转移数据。DTS Wizard还允许您在关系型数据库之间拷贝图解(schema)和数据。   
  
  
 SQL Server 查询分析器(Query Analyzer)SQL Server 查询分析器是一种图形化的查询工具，通过它您可以分析一个查询，同时执行多个查询，查看数据和获取索引建议。SQL Server 查询分析器提供了showplan选项，可用来显示SQL Server查询优化器所选择的数据提取方法。   
  
  
 SQL ServerProfiler,SQL Server Profiler可以实时地捕获数据库服务器活动的连续记录。SQL Server Profiler允许您监控SQL Server产生的事件，过滤基于用户指定标准的事件，或将操作步骤输出到屏幕、文件或数据表。运用SQL Server Profiler，您可以重新执行所捕获的上一次操作。这种工具可以帮助应用程序开发者识别那些可能会降低应用程序性能的事务处理。在将一个基于文件体系结构的应用程序移植到客户/服务器结构中时该特性是很有用的，因为它的最后一步包括对面向新的客户/服务器环境的应用程序进行优化。   
 MySQL 和 SQL Server 都属于服务器级的数据库系统，它们无论在性能、稳定性、安全性等方面都比 Access 等文件型的数据要高很多，并且 Access 数据库支持的并发数很少，对于大型网站来说根本无法用，所以一般来说访问量比较大的网站,比如日IP1000以上网站，建议采用 MySQL 或 SQL Server 的数据库，具体请根据您的网站程序是用哪种数据库进行选择。  
 耐思尼克顶级注册商（iisp.com/vhost/vhost_diy.php?s=cyp）的数据库空间全面支持 MySQL5.0、SQLServer2000。  
  
  
 转移表和数据   
  
  
 使用DTS Wizard将您的Access数据转移到SQL Server，可采取以下步骤：   
  
  
 在 SQL Server Manager(Enterprise Manager)的工具菜单中，鼠标指向“DataTransformation Services”, 然后点击“Import Data.”在“选择数据源”( Choose a Data Source)的对话窗口中，选择MicrosoftAccess为数据源，然后输入您的.mdb文件名(mdb为文件扩展名)或者选择浏览文件。   
  
  
 在“选择数据目标”(Choose a Destination)的对话窗口中，选择“Microsoft OLE DB Provider for SQL Server”，再选择好数据库服务器，然后点击所需的认证模式。   
  
  
 在“指定表备份或查询”( Specify Table Copy or Query)的对话窗口中，点击“拷贝表”(Copytables)。   
  
  
 在“选择数据源”的对话窗口中，点击“选择所有项”( Select All)。   
  
  
 移植Microsoft Access查询   
  
  
 您可以将Access的查询以下面的格式之一转移至SQL Server中：   
  
  
 事务处理SQL脚本程序(Transact-SQL scripts )   
  
  
 事务处理SQL语句通常是由数据库程序调用的，但是您也可以使用SQL Server 7.0中包含的SQL Server 查询分析器直接运行它们。SQL Server 查询分析器可帮助开发者测试事务处理SQL语句，或运行那些执行查询处理、数据操作(插入，修改，删除)和数据定义(创建表)的事务处理SQL语句。   
  
  
 存储过程(Stored procedures )   
  
  
 开发者可以将大部分产生自Access查询(查找，插入，修改，删除)的事务处理SQL语句转移至存储过程。用事务处理SQL语句书写的存储过程可以用来对您的数据存取打包，并使之标准化，而且存储过程实际上是存储在数据库中的。存储过程可以带参数，也可不带参数，可以由数据库程序调用或者由SQL Server查询分析器手动执行。   
  
  
 视图(Views )   
  
  
 视图是从一个或多个表中显示特定的行和列的虚拟表。它们允许用户可以不直接执行构成查询基础的复杂连接而建立查询。视图不支持参数的使用。连接多个数据表的视图不能用INSERT, UPDATE或 DELETE语句来修改。视图由事务处理SQL语句调用，也可用于SQL Server查询分析器中运行的程序段。SQL Server视图和SQL-92标准不支持视图中的ORDER BY排序子句。如欲了解事务处理SQL，存储过程和视图的其他信息，请参阅SQL Server 在线参考书。   
  
  
 Access查询类型的SQL Server移植选择与建议   
  
  
 一个SELECT语句可以存储在事务处理SQL文件、存储过程或是视图中。建立存储过程是将数据库应用开发与数据库设计的物理实施分开的最佳方法。存储过程可在一处创建而由应用程序调用。   
  
  
 如果存储过程所基于的数据库变化了，而存储过程经过仔细的修改以反应这些变化，则对存储过程的调用将不会受到破坏。   
  
  
 交叉表(CROSSTAB)   
  
  
交叉表经常用于总结报表。一个Access的交叉表可以通过SQL程序段、存储过程或视图中的事务处理SQL语句来执行。每当发出一个查询时，数据连接被重现执行以确保最近的数据得到使用。根据实际应用情况，比较合适的方法是将交叉表中的数据存储为一个临时表(参考下面的MAKE TABLE)，临时表对资源的需求比较少，但是临时表在建立的同时只提供对数据的一个快照(snapshot)。