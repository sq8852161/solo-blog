title: 在CentOS中安装GitLab，部署属于自己Git仓库
date: '2019-08-27 11:59:59'
updated: '2019-08-27 11:59:59'
tags: [Git]
permalink: /articles/2019/08/27/1566878399484.html
---
GitLab是比较优秀的一款Git仓库。它有社区版和商业版。
它的社区版和商业版都是可以免费获取，并且部署的，而且可以通过源码打包的方式，进行汉化。
![gitlab.PNG](https://img.hacpai.com/file/2019/08/gitlab-4b6af8a4.PNG)



### 1. 备份本地yum源
```
 mv /etc/yum.repos.d/CentOS-Base.repo /etc/yum.repos.d/CentOS-Base.repo_bak 
 ```
### 2.获取阿里yum源配置文件
```
 wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-7.repo 
 ```
### 3.更新cache
```
 yum makecache 
```
### 4.查看
```
 yum -y update 
```

### CentOs7
### 1在CentOS 7（和RedHat / Oracle / Scientific Linux 7）上，以下命令还将在系统防火墙中打开HTTP和SSH访问。
```
sudo yum install -y curl policycoreutils-python openssh-server
sudo systemctl enable sshd
sudo systemctl start sshd
sudo firewall-cmd --permanent --add-service=http
sudo systemctl reload firewalld
```



### 2接下来，安装Postfix以发送通知电子邮件。如果要使用其他解决方案发送电子邮件，请跳过此步骤并在安装GitLab后配置外部SMTP服务器。
```
sudo yum install postfix
sudo systemctl enable postfix
sudo systemctl start postfix
```

### 2.添加GitLab软件包存储库并安装软件包
添加GitLab包存储库。
```
curl https://packages.gitlab.com/install/repositories/gitlab/gitlab-ee/script.rpm.sh | sudo bash
```

接下来，安装GitLab包。
更改https://gitlab.example.com为您要访问GitLab实例的URL。安装将自动配置并启动该URL的GitLab。
对于https://URL，GitLab将自动使用Let's Encrypt请求证书，该证书需要入站HTTP访问和有效的主机名。您也可以使用自己的证书或只使用http：//。
```
sudo EXTERNAL_URL="https://gitlab.example.com" yum install -y gitlab-eesudo EXTERNAL_URL =“https://gitlab.example.com”yum install -y gitlab-ee
```
### 3.浏览到主机名并登录
```
在您第一次访问时，您将被重定向到密码重置屏幕。提供初始管理员帐户的密码，您将被重定向回登录屏幕。使用默认帐户的用户名root登录。
密码：root
```
### 汉化
查看版本
```
cat /opt/gitlab/embedded/service/gitlab-rails/VERSION
$ git clone https://gitlab.com/xhang/gitlab.git  -b  v10.0.0-zh
```
或者获取所有
```
git clone https://gitlab.com/xhang/gitlab.git
 \cp -r -f ./gitlab/* /opt/gitlab/embedded/service/gitlab-rails/  （推荐）
```

**完成后 在个人设置里面 Preferred language 选项选择 中文简体**
(当时在这里卡了好久，几度以为汉化不成功)

### 如果虚拟机重启后，gitlab无法打开，请
```
sudo systemctl enable sshd
sudo systemctl start sshd
sudo firewall-cmd --permanent --add-service=http
sudo systemctl reload firewalld

sudo systemctl enable postfix
sudo systemctl start postfix
```


