title: tomcat部署项目
date: '2014-07-19 00:19:26'
updated: '2014-07-19 00:19:26'
tags: [CSDN迁移]
permalink: /articles/2014/07/19/1566182613838.html
---
找到Tomcat的安装目录，然后找到D:/Tomcat 6.0/conf中的server.xml和web.xml

 在server.xml中加入这样一些代码：

 <Context path="" docBase="D:/workspace/pric/war"  
 reloadable="true" debug="0">  
 </Context>

 紧跟后面的是 这样些代码

 </Host>  
 </Engine>  
 </Service>  
 </Server>

 

 其中 docBase是你要部署项目的路径war就相当于web项目的WebRoot目录， reloadable=true,那么每当相关文件改变时，Tomcat会停止web app并释放内存,然后重新加载web app

 

 在web.xml中，把 <init-param>  
 <param-name>listings</param-name>  
 <param-value>false</param-value>  
 </init-param>  
 <load-on-startup>1</load-on-startup>

 改为：

 <init-param>  
 <param-name>listings</param-name>  
 <param-value>true</param-value>  
 </init-param>  
 <load-on-startup>1</load-on-startup>

 就OK了