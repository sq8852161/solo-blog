title: 关于PowerDesigner导出SQLServer 2008表结构的问题
date: '2014-02-10 17:57:40'
updated: '2014-02-10 17:57:40'
tags: [CSDN迁移]
permalink: /articles/2014/02/10/1566182601629.html
---
我们经常用PowerDesigner的反向工程导出[数据库](http://www.2cto.com/database/)的表结构，像导出[Oracle](http://www.2cto.com/database/Oracle/)数据库表结构，我们用客户端连接方式。而我们这是用客户端连接方式导出SQLServer 2008的表结构，在连接数据库是连接成功的，结果导出表结构缺失败了。

 ![\](http://up.2cto.com/2011/1004/20111004103843107.gif)

 结果就报上面的42000错误。

 最后查看了一些资料，最后知道采用ODBC的方式连接是可以导出表结构成功的。

 因此在ODBC数据源管理器中创建ODBC数据源。见下图。

 ![\](http://up.2cto.com/2011/1004/20111004103844996.gif)

 在配置ODBC的时候，不要更改了默认数据库（也就是点击了“更改默认数据库”的复选框选，并从数据库列表中选中你需要反向工程的数据库）就会出现"Unable to list Tables”,SqlState=3700的错误。

 ![\](http://up.2cto.com/2011/1004/20111004103844981.gif)、

 

 摘自 jianyi7659的专栏