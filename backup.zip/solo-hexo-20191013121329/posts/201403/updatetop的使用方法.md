title: update top的使用方法
date: '2014-03-13 20:00:23'
updated: '2014-03-13 20:00:23'
tags: [CSDN迁移]
permalink: /articles/2014/03/13/1566182599979.html
---
[ ](http://creativecommons.org/licenses/by-sa/4.0/) 版权声明：本文为博主原创文章，遵循[ CC 4.0 by-sa ](http://creativecommons.org/licenses/by-sa/4.0/)版权协议，转载请附上原文出处链接和本声明。  本文链接：[https://blog.csdn.net/u012274449/article/details/21163785](https://blog.csdn.net/u012274449/article/details/21163785)   
    
   update top（10） dtms_doc_canuse where ...后边是不能跟order by的 因此可以这么处理

 

 update dtms_doc_sendlinetool set issign='1' where drilltool_id in  
 (select top 3 drilltool_id from dtms_doc_sendlinetool where send_id='S10102022014031203'  
 and sendline_id='SL101020220140312005' order by case when drilltool_id in('') then 1  
 when isnull(drilltool_no,'')='' then 2 else 3 end )