title: sql中top使用方法
date: '2014-02-23 01:37:40'
updated: '2014-02-23 01:37:40'
tags: [CSDN迁移]
permalink: /articles/2014/02/23/1566182614053.html
---
在编写程序中，我们可能遇到诸如查询最热门的5篇文章或返回满足条件的n条记录的情况，在SQL语言中，可以使用TOP关键字来实现。  
  
 TOP关键字在SQL语言中用来限制返回结果集中的记录条数，其使用方法有两种形式，下面做以详细的介绍：  
  
 （1）返回确定数目的记录个数  
  
 语法格式： SELECT TOP n <列名表> FROM <表名> [查询条件]  
  
 其中，n为要返回结果集中的记录条数  
  
 （2）返回结果集中指定百分比的记录数  
  
 语法格式： SELECT TOP n PERCENT <列名表> FROM <表名> [查询条件]  
  
 其中，n为所返回的记录数所占结果集中记录数目的百分比数  
  
 举例说明：  
  
 假设数据库中有一个表存储的为学生的信息（student）：  
  
 （1）SELECT TOP 20 * FROM student --查询前20名学生的信息  
  
 （2）SELECT TOP 20 * PERCENT FROM student --查询学生表中前20%的学生信息  
  
 在具体使用过程中，可以结合条件子句和排序子句（如何进行排序）等实现较为丰富的功能，如：  
  
 （1）查询年龄（sage）大于23的前20名学生的信息  
  
 查询语句为：SELECT TOP 20 * FROM student WHERE sage > 23  
  
 （2）查询年龄较为大的前20名学生的信息  
  
 查询语句为： SELECT TOP 20 * FROM student ORDER BY sage DESC  
  
 在假设有一个表为新闻表（news），其列名定义如下：  
  
 ID 新闻编号， 整数型 自增字段  
  
 Title 新闻标题 ， 字符串型(varchar)   
  
 Content 新闻内容，Text型  
  
 Hits 点击次数， 整数类型  
  
 AddDateTime 添加时间 ，字符串（YYYY-MM-DD)  
  
 则要求查询：  
  
 （1）查询最新10条新闻，只列出新闻标题和添加时间  
  
 SELECT TOP 10 Title, AddDateTime FROM News ORDER BY AddDateTime DESC  
  
 说明：如果新闻增加时是按时间发生的先后顺序添加的话，也可以按ID来排序（因为ID为自增字段，ID越大的应越新），即：  
  
 SELECT TOP 10 Title, AddDateTime FROM News ORDER BY ID DESC  
  
 （2）查询最热门的8条新闻的标题和点击次数  
  
 查询语句为： SELECT TOP 8 Title, Hits FROM News ORDER BY Hits DESC 

 转自：http://www.biye5u.com/article/db/SQLs/2012/5223.html