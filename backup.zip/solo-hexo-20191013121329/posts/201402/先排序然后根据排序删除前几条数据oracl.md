title: 先排序，然后根据排序删除前几条数据oracl
date: '2014-02-23 01:36:57'
updated: '2014-02-23 01:36:57'
tags: [CSDN迁移]
permalink: /articles/2014/02/23/1566182610191.html
---
同分页查询一样，是3层结构的子查询  
 delete from stockpile where rowid in  
 (select ROWID from  
 (select rowid from stockpile where username='fttc' order by xhasc)  
 whererownum<5)  
 /  
 如果是2层结构的就不可以，2层结构如下：  
 delete from stockpile where rowid in  
 (select rowid fromstockpile where username='fttc' order by xh asc)  
 where rownum<5;  
 这是因为这个是在子查询嵌套里，不允许直接嵌套orderby，虽然这里也是top-n的子查询。一般orderby只在top-n子查询里起作用，但是这个子查询是作为一个结果集，例如：  
 select xh from  
 (select xh from stockpilewhere username='fttc' order by xh asc)  
 where rownum<5;  
 另外说明：TOP-N一般是指最大的n条记录或着是最小的n条记录。  
  
 如：  
 select rownum , t.col1, t.col2, ... from  
 ( select col1, col2, ... from tab  
 order by col1 ) t  
 where rownum <= n;