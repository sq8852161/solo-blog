title: Doxygen + Graphviz windows下安装配置（图解）
date: '2015-01-09 18:24:43'
updated: '2019-08-19 10:46:32'
tags: [文档, 关系图]
permalink: /articles/2015/01/09/1566182610469.html
---
要使用doxygen生成漂亮的调用关系图，那就必须安装下图形生成工具graphviz软件，要通过html生成chm文档，那就要用htmlhelp软件了，我想已经说明了三者的关系了，哦，至于doxygen做什么，生成html文档或其他格式的文档软件撒

 

 首先下载三个软件，均下载windows下的安装包，

 地址如下：

 doxygen：[http://sourceforge.net/projects/doxygen/](http://sourceforge.net/projects/doxygen/) 我用的最新版1.7.6.1

 Graphviz ：[http://www.graphviz.org/Download..php](http://www.graphviz.org/Download..php) 记得选择windows下的版本哟![吐舌头](http://static.blog.csdn.net/xheditor/xheditor_emot/default/tongue.gif) “[Stable and development Windows Install packages](http://blog.csdn.net/fly542/article/details/Download_windows.php)”

 

 htmlhelp：[http://www.softpedia.com/get/Authoring-tools/Help-e-book-creators/HTML-Help-Workshop.shtml](http://www.softpedia.com/get/Authoring-tools/Help-e-book-creators/HTML-Help-Workshop.shtml) 

 

 首先安装Graphviz ，再安装doxygen，安装没什么，一路next就ok了

 

 下面就讲解下如何使用了

 运行doxygen的步骤和基本界面如下图，

 ![](http://hi.csdn.net/attachment/201112/30/0_1325220422vxkF.gif)

 ![](http://hi.csdn.net/attachment/201112/30/0_1325220454AV61.gif)

 ![](http://hi.csdn.net/attachment/201112/30/0_13252204729sy5.gif)

 ![](http://hi.csdn.net/attachment/201112/30/0_1325220484ww1Y.gif)

 ![](http://hi.csdn.net/attachment/201112/30/0_13252205002u28.gif)

 ![](http://hi.csdn.net/attachment/201112/30/0_132522051666fe.gif)

 

 以上运行完毕就已经生成了相应的html文档页面，如果不需要chm文档，那就不用往下看了，赶紧去试试吧![大笑](http://static.blog.csdn.net/xheditor/xheditor_emot/default/laugh.gif)

 

 付：

 Doxygen中文乱码问题：

 设置如下：

 Expert选项卡-> Project:

 DOXYFILE_ENCODING:UTF-8

 OUTPUT_LANGUAGE:Chinese

 Expert选项卡-> InPut:

 INPUT_ENCODING:GB2312

 这样生就可以正确生成含有中文的文档了。

 转自：http://blog.csdn.net/fly542
