title: Spring JdbcTemplate 批量插入或更新操作
date: '2014-03-14 18:14:31'
updated: '2014-03-14 18:14:31'
tags: [CSDN迁移]
permalink: /articles/2014/03/14/1566182604104.html
---
Spring JdbcTemplate 批量插入或更新操作

 用 JdbcTemplate 进行批量插入或更新操作

 方法一：

 代码只是测试用的一个小例子。

 public int insertContractAch(List list) throws DataAccessException {   
 final List temList = list;   
 String sql = "insert into contract_ach_t " +   
 " values(?,to_date(?,'yyyy-mm-dd'),?,?) ";   
 try{   
 int[] ii = this.getJdbcTemplate().batchUpdate(sql, new MyBatchPreparedStatementSetter(temList));   
 return ii.length;   
 }catch (org.springframework.dao.DataAccessException e) {   
 e.printStackTrace();   
 throw new DataAccessException(e.getMessage());   
 }   
 }   
 /**   
 * 处理批量插入的回调类   
 * */   
 private class MyBatchPreparedStatementSetter implements BatchPreparedStatementSetter{   
 final List temList;   
 /**通过构造函数把要插入的数据传递进来处理*/   
 public MyBatchPreparedStatementSetter(List list){   
 temList = list;   
 }   
 public int getBatchSize() {   
 return temList.size();   
 }   
   
 public void setValues(PreparedStatement ps, int i)   
 throws SQLException {   
 ContractAchVO contractAchVO = (ContractAchVO)temList.get(i);   
 ps.setString(1, contractAchVO.getContractCode());   
 ps.setString(2, contractAchVO.getCreateDate());   
 ps.setString(3, contractAchVO.getEmployeeId());   
 ps.setString(4, contractAchVO.getPercent());   
 }   
 } 

 方法二：

 //插入很多书(批量插入用法)   
 public void insertBooks(List<Book> book)   
 {   
 final List<Book> tempBook=book;   
 String sql="insert into book(name,pbYear) values(?,?)";   
 jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter()   
 {   
 public void setValues(PreparedStatement ps,int i)throws SQLException   
 {   
 String name=tempBook.get(i).getName();   
 int pbYear=tempBook.get(i).getPbYear();   
 ps.setString(1, name);   
 ps.setInt(2, pbYear);   
 }   
 public int getBatchSize()   
 {   
 return tempBook.size();   
 }   
 });   
   
 }