title: 安装、设置与启动MySql绿色版的方法
date: '2014-03-29 18:22:58'
updated: '2014-03-29 18:22:58'
tags: [CSDN迁移]
permalink: /articles/2014/03/29/1566182603558.html
---
1、解压 mysql-noinstall-5.1.30-win32.zip(下载地址http://dev.mysql.com/downloads/mysql/5.1.html)  
 2、在 F 盘建立目录 MySql\MySqlServer5.1\   
 3、把解压的内容复制到 F:\MySql\MySqlServer5.1\  
 4、在 F:\MySql\MySqlServer5.1\ 中找 my-large.ini 把它复制成 my.ini  
 5、在 my.ini 中找 [mysqld] ，添加以下语句;  
  basedir="F:/MySql/MySqlServer5.1/"  
 datadir="F:/MySql/MySqlServer5.1/data/"  
 default-character-set=latin1 #utf8  
 default-storage-engine=innodb   
 max_allowed_packet =12M  
  #skip-networking #// 这句会忽略网络登陆  
 #bind-address=192.168.0.72 #// 如果加上这句 localhost 就用不了 只要改 user 表的 127.0.0.1 为 % 重启服务 就可以远程登陆  
  6、安装 MySQL_Administrator_1.2 绿色版：把 mysql-gui-tools-noinstall-5.0-r14-win32.zip 解压到 F:\MySql\MySQL GUI Tools 5.0  
 6.5、可以尝试手动启动 MySql 服务器，并用 MySQL_Administrator_1.2 和 console 登陆：  
 1、手动启动服务：cmd --> F:\MySql\MySqlServer5.1\bin\mysqld --console  
 会看到 InnoDB: The first specified datafile c:\ibdata\ibdata1 did not exist:  
 InnoDB: a new database to be created！  
 InnoDB: Setting file c:\ibdata\ibdata1 size to 209715200  
 InnoDB: Database physically writes the file full: wait... 等 很长的  
 最后看到 mysqld: ready for connections  
 Version: '5.1.2-alpha' socket: '' port: 3306  
 表示 MySql 服务已经启动，可以登陆了，这时： 登陆名是 root ，密码为空，IP 地址只能写 localhost 或 127.0.0.1 ，因为现在  
 root 的权限只允许本地登陆，远程登陆不可以，在本机写本机 IP 地址来登陆被 MySql 视为远程登陆，所以是登陆不了的，会报错 1130  
 2、MySQL_Administrator_1.2 登陆：到 F:\MySql\MySQL GUI Tools 5.0\ 运行 MySQLAdministrator.exe ，  
 填入 localhost或127.0.0.1 3306 root 密码为空 就可以登陆  
 3、用 console 登陆: cmd --> f:\MySql\MySqlServer5.1\bin\mysql -u root -p  
 密码为空  
 如果要在登陆时就选定数据库可以这样写：f:\MySql\MySqlServer5.1\bin\mysql -u root -p[密码] [数据库名]  
 当前情况举例：f:\MySql\MySqlServer5.1\bin\mysql -u root -p mysql 就是密码是空的，登陆的数据库是 mysql 库   
 4、修改root的密码、让root可以远程登陆、添加新用户  
 修改root的密码:在登陆后的 console 中输入   
 use mysql  
 update user set Password=PASSWORD('[密码]') where user='root';  
 让root可以远程登陆:在登陆后的 console 中输入  
 use mysql  
 update user set Host='%' where user='root' and Host='127.0.0.1';  
 添加新用户，用户名是 gary，密码为空，权限等于root，用户允许远程登陆 :在登陆后的 console 中输入  
 GRANT ALL PRIVILEGES ON *.* TO 'gary'@'%';  
 如果用户不可以远程登陆：GRANT ALL PRIVILEGES ON *.* TO 'gary'@'localhost';  
 然后用上面的方法修改gary的密码，root 改为 gary  
 5、手工停止 MySql 服务：cmd --> F:\MySql\MySqlServer5.1\bin\mysqladmin -u root shutdown   
 如果MySQL root用户账户有密码，你需要调用命令 F:\MySql\MySqlServer5.1\bin\mysqladmin -u root -p shutdown 并根据提示输入密码。  
   
 注意：修改密码、修改是否远程登陆，添加用户后必须重启MySql服务才生效 !!!!!!!!!!!!!!!!!!!!!!!!!!!  
 注意: MySQL权限系统中的用户完全独立于Windows下的登录用户。  
   
 7、添加 MySql 服务到windows服务中：  
 1、简易添加方法：cmd --> F:\MySql\MySqlServer5.1\bin\mysqld --install 这样用默认的 MySQL 为名称添加一个windows服务  
 这是，该服务的属性写着：F:\MySql\MySqlServer5.1\bin\mysqld MySQL  
 2、指定服务名称与指定启动选项文件的添加方法：  
 F:\MySql\MySqlServer5.1\bin\mysqld --install LevelDBServer --defaults-file=F:\MySql\MySqlServer5.1\my.ini  
 用 LevelDBServer 为名称来创建windows服务，指定 F:\MySql\MySqlServer5.1\my.ini 为MySql的启动选项文件  
  如果在服务安装命令中，在--install选项后面指定的服务名不是默认服务名(MySQL)。则从具有相同服务名的组中读取选项，并从标准选项文件读取选项。  
 服务器还从标准选项文件的[mysqld]组读取选项。你可以使用[mysqld]组中的选项用于所有MySQL 服务，还可以使用具有相同服务名的组，用于该服务名所对应的服务器。  
  该命令中，--install选项后面给出了默认服务名(MySQL)。如果未给出--defaults-file选项，该命令可以让服务器从标准选项文件的[mysqld]组中读数。  
 由于提供了--defaults-file选项，服务器只从命名文件的[mysqld]组读取选项。  
   
 注意：添加服务后该服务并未启动。重启电脑服务就会启动，要手动启动与关闭 MySql 服务用以下语句：  
 cmd --> NET START MySQL 或 NET START LevelDBServer , NET STOP MySQL 或 NET STOP LevelDBServer  
  8、测试MySQL安装  
 可以通过以下命令测试MySQL服务器是否工作：  
 C:\> F:\MySql\MySqlServer5.1\bin\mysqlshow  
 C:\> F:\MySql\MySqlServer5.1\bin\mysqlshow -u root mysql  
 C:\> F:\MySql\MySqlServer5.1\bin\mysqladmin version status proc  
 C:\> F:\MySql\MySqlServer5.1\bin\mysql test  
 如果mysqld对客户端程序TCP/IP连接的响应较慢，可能是DNS问题。此时，使用--skip-name-resolve选项启动 mysqld，在MySQL授权表的Host列只使用localhost和IP号。  
 可以通过 --pipe 或 --protocol=PIPE 选项强制 MySQL 客户端使用命名管道连接代替TCP/IP连接，或指定.(阶段)做为主机名。使用 --socket 选项指定管道名。